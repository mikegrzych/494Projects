﻿using UnityEngine;
using System.Collections;

[RequireComponent (typeof (Collider))]
public class Spring : MonoBehaviour {

	public float spring_force = 600.0f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider in_collider) {

		Hurtbox hurtbox = in_collider.gameObject.GetComponent<Hurtbox>();
		DestructableHurt desthurt = in_collider.gameObject.GetComponent<DestructableHurt>();

		//Don't add force if hurtbox doesn't exist
		if (hurtbox == null && desthurt == null) return;

		Vector3 knockback_force = transform.up.normalized * spring_force;
		in_collider.transform.root.rigidbody.velocity = new Vector3();

			//Get target
//			CharacterStatus target = hurtbox.character_status;
			//print (hurtbox.character_status.name.ToString());
			//give knockback
			in_collider.transform.root.GetComponent<Movement>().add_force(knockback_force);
		print("spring applied to: " + in_collider.name + " force: " + knockback_force.ToString());
	}
}
