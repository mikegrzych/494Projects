﻿using UnityEngine;
using System.Collections;

public class PointListener : MonoBehaviour {
	public TeamId conditionTeam;
	private MonoBehaviour[] scripts;

	void UpdateTeam(TeamId controller) {
		print("Received UpdateTeam call");
		if (enabled == false)
			return;
		if (controller == conditionTeam) {
			gameObject.GetComponent<Renderer>().enabled = true;
			gameObject.transform.Find("GameObject").renderer.enabled = true;
			gameObject.GetComponent<Collider>().enabled = true;
			scripts = gameObject.GetComponents<MonoBehaviour>();
			foreach(MonoBehaviour sc in scripts) {
				sc.enabled = true;
			}
		} else {
			gameObject.GetComponent<Renderer>().enabled = false;
			gameObject.transform.Find("GameObject").renderer.enabled = false;
			gameObject.GetComponent<Collider>().enabled = false;
			scripts = gameObject.GetComponents<MonoBehaviour>();
			foreach(MonoBehaviour sc in scripts) {
				if (sc != this)
					sc.enabled = false;
			}
		}
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
