﻿using UnityEngine;
using System.Collections;

public class DestructableKnockback : MonoBehaviour {

	public bool direction;	//left 0 - right 1
	float knockbackAngle = -45f * Mathf.PI/180;
	float knockbackMagnitude = 500f;

	// Use this for initialization
	void Start () {
		if (direction)
			knockbackAngle = Mathf.PI - knockbackAngle;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other) {
		if (!enabled) return;
		print("collided object has tag " + other.gameObject.tag);
		if ("Player" == other.gameObject.tag) {
//			Movement mov = collision.gameObject.GetComponent<Movement>();
			Vector3 knockbackForce = new Vector3();
			knockbackForce.x = knockbackMagnitude * Mathf.Cos(knockbackAngle);
			knockbackForce.y = knockbackMagnitude * Mathf.Sin(knockbackAngle);
			other.transform.root.GetComponent<Movement>().add_force(knockbackForce);
			print("knocked back " + other.gameObject.name);
		}

	}

}
