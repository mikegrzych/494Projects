﻿using UnityEngine;
using System.Collections;

public class DestructableHurt : Hitbox {

	public DestructableStatus target_status {
		
		get {
			
			return transform.root.GetComponent<DestructableStatus>();
		}
	} 
	
	// Use this for initialization
	void Start () {
		
		//character_status = transform.root.GetComponent<CharacterStatus>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	//Effect the certain hitbox will perform
	public virtual void Effect(Hitbox hitbox) {
		
		//Do nothing on effects
	}
}
