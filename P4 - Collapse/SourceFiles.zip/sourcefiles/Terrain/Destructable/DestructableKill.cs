﻿using UnityEngine;
using System.Collections;

public class DestructableKill : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider other) {
		if(!enabled) return;
		if ("Player" == other.gameObject.tag) {
			CharacterStatus cs = other.gameObject.GetComponent<CharacterStatus>();
//			Vector3 knockbackForce = new Vector3();
//			knockbackForce.x = knockbackMagnitude * Mathf.Cos(knockbackAngle);
//			knockbackForce.y = knockbackMagnitude * Mathf.Sin(knockbackAngle);
//			collision.transform.root.GetComponent<Movement>().add_force(knockbackForce);
//			print("knocked back " + collision.gameObject.name);
			cs.current_hitpoints -= 1000f;
			print("Falling and BRUTALLY CRUSHING player " + other.gameObject.name);
		}
		
	}
}
