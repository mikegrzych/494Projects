﻿using UnityEngine;
using System.Collections;

public class DestructableStatus : MonoBehaviour {

	public Vector3 spawn_pos;
	public CharacterStats destructable_stats;

	const float max_hitpoints = 200f;
	Vector3 respawn_point;
	float m_current_hitpoints;
	bool m_loose = false;
	bool m_lethal = false;
	public Shader m_shader_opaque;
	public Shader m_shader_transparent;
	public GameObject Killbox;
	public GameObject KnockLeft;
	public GameObject KnockRight;

	public float current_hitpoints {
		
		get {
			return m_current_hitpoints;
		}
		set {
			
			SetCurrentHitpoints(value);
			networkView.RPC("RPC_SetCurrentHitpoints", RPCMode.All, value);
			print("current hitpoints: " + current_hitpoints);
		}
	}

	void SetCurrentHitpoints(float value) {
		
		if (value > max_hitpoints) {
			
			m_current_hitpoints = max_hitpoints;
		}
		else {
			
			m_current_hitpoints = value;
		}
	}

	void Awake () {
		m_shader_opaque = Shader.Find("Diffuse");
		m_shader_transparent = Shader.Find("Transparent/Diffuse");
		SetCurrentHitpoints (max_hitpoints);
//		SetCurrentHitpoints (0f);
		renderer.material.shader = m_shader_opaque;
		destructable_stats = new CharacterStats(300, 0, 100, 100, 50);
		respawn_point = new Vector3(transform.position.x,transform.position.y,transform.position.z);
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (!m_loose) {
			if (current_hitpoints <= 0) {
				m_loose = true;
//				rigidbody rb = GetComponent<Rigidbody>();
				rigidbody.constraints = RigidbodyConstraints.None | RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotation;
//				rigidbody.freezeRotation = false;
				rigidbody.isKinematic = false;
				StartCoroutine(Respawn ());
			}
		} else {
			if (m_lethal && rigidbody.velocity.y >= -0.5f) {
				m_lethal = false;
//				KnockLeft.GetComponent<DestructableKnockback>().enabled = false;
//				KnockRight.GetComponent<DestructableKnockback>().enabled = false;
				Killbox.GetComponent<DestructableKill>().enabled = false;
			} else if (!m_lethal && rigidbody.velocity.y < -0.1f) {
				m_lethal = true;
//				KnockLeft.GetComponent<DestructableKnockback>().enabled = true;
//				KnockRight.GetComponent<DestructableKnockback>().enabled = true;
				Killbox.GetComponent<DestructableKill>().enabled = true;
			}
		}
	}

	public IEnumerator Respawn() {
		Vector3 spawn_offset = new Vector3(0f, 0f, 1f);
//		Movement mov = transform.GetComponent<Movement>();
//		mov.enabled = false;

		print("box will be free for 10s");
		yield return new WaitForSeconds(10.0f);	
		print("box will respawn in 5s");
		//constrain the block again
		transform.rotation = Quaternion.identity;
		rigidbody.velocity = Vector3.zero;
		rigidbody.isKinematic = true;
//		rigidbody.freezeRotation = true;
		rigidbody.constraints = RigidbodyConstraints.FreezeAll;


		
		//set position
		transform.position = respawn_point + spawn_offset;


//		mov.enabled = true;
		
		//set respawn animation
		Color mat_color = renderer.material.color;
		mat_color.a = 0.5f;
		renderer.material.shader = m_shader_transparent;
		renderer.material.color = mat_color;

		yield return new WaitForSeconds(5.0f);

		//set health back
		m_loose = false;
		current_hitpoints = max_hitpoints;

		mat_color.a = 1.0f;
		renderer.material.shader = m_shader_opaque;
		renderer.material.color = mat_color;
		transform.position = respawn_point;
	}

	[RPC]
	void RPC_SetCurrentHitpoints(float hp) {
		
		SetCurrentHitpoints(hp);
	}
}
