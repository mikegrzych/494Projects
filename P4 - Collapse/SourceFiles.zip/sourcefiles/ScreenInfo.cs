﻿using UnityEngine;
using System.Collections;

public class ScreenInfo : MonoBehaviour {

	public float Width;
	public float Height;
	public float CenterHorizontal;
	public float CenterVertical;
	public float TenthHorizontal;
	public float TenthVertical;
	public float[] HorizontalGrid = new float[11];
	public float[] VerticalGrid = new float[11];

	void Awake() {
		DoUpdate();
	}

	void DoUpdate() {
		Width = Screen.width;
		Height = Screen.height;
		CenterVertical = Screen.height * 0.5f;
		CenterHorizontal = Screen.width * 0.5f;
		TenthHorizontal = Screen.width * 0.1f;
		TenthVertical = Screen.height * 0.1f;
		for (int row = 0; row <= 10; ++row) {
			VerticalGrid[row] = row * TenthVertical;
		}
		for (int col = 0; col <= 10; ++col) {
			HorizontalGrid[col] = col * TenthHorizontal;
		}
	}
}
