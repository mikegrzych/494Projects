﻿using UnityEngine;
using System.Collections;

public class BasicCameraFollow : MonoBehaviour {

	public Transform target;
	public Vector3 temp;
	public string targetName;

	// Use this for initialization
	void Start () {
		target = GameObject.Find("Character1").transform;

	}
	
	// Update is called once per frame
	void Update () {
		print ("target.x is "+target.position.x);
		temp.x = target.position.x;
		temp.y = target.position.y + 1;
		temp.z = -10;
		transform.position = temp;
	}

	void SetTargetName(string name) {
		targetName = name;
	}
}
