﻿using UnityEngine;
using System.Collections;

public class SmartCameraFollow : MonoBehaviour {
	
	public Transform target;
	public Vector3 temp;
	public string targetName = "Character1";
	public const float x_damping = 5.0f;
	public const float y_damping = 10.0f;
	public float heightOffset = 2.5f; //because we don't want the ground taking up half the screen
	
	// Use this for initialization
	void Start () {
		SetTargetName("golem");
//		target = GameObject.Find(targetName).transform;
		temp.x = target.position.x;
		temp.y = target.position.y + heightOffset;
		temp.z = -10;
		
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		
		float delta_x = Mathf.Lerp(transform.position.x, target.position.x, Time.deltaTime * x_damping);
		float delta_y = Mathf.Lerp(transform.position.y, target.position.y+heightOffset, Time.deltaTime * y_damping); 


		//print ("dt, damping, dt*damping is "+Time.deltaTime+","+damping_var+"," + Time.deltaTime * damping_var);
		temp.x = delta_x;
		temp.y = delta_y;
		temp.z = -10;

		transform.position = temp;

	}
	
	void SetTargetName(string name) {
		targetName = name;
	}
}
