﻿using UnityEngine;
using System.Collections;

public class RobotAlphaController : CharacterController {
	
	// Use this for initialization
	protected override void init() {
		
	}
	
	// Update is called once per frame
	protected override void update_loop() {
		
	}
	
	public override void standard_attack() {	
		
		Movement movement = transform.GetComponent<Movement>();
		
		//get airborn melee attack input
		if (!movement.is_grounded) {
			networkView.RPC("RPC_Melee", RPCMode.All, "AirborneAttackContainer", 50f, 1f, 150f, 0.3f, 0.35f,
			                true, (int)AnimationState.AnimationAttackState.NONE);
		}
		//get running melee attack input
		else if (rigidbody.velocity.x < -Movement.change_direction_threshold ||
		         rigidbody.velocity.x > Movement.change_direction_threshold) {
			networkView.RPC("RPC_Melee", RPCMode.All, "RunningAttackContainer", 60f, 1f, 300f, 0.3f, 0.35f,
			                false, (int)AnimationState.AnimationAttackState.NONE);
		}
		//get melee attack input
		else {

			CharacterStatus character_status = transform.root.GetComponent<CharacterStatus>();
			character_status.charge_value += Time.deltaTime;

			transform.root.GetComponent<Movement>().can_move = false;
		}
	}

	public override void charge_attack() {

		CharacterStatus character_status = transform.root.GetComponent<CharacterStatus>();
		float charge_ratio = character_status.charge_value / character_status.max_charge_value;
		networkView.RPC("RPC_Melee", RPCMode.All, "AttackContainer", 50f + 100f * charge_ratio, 1f, 200f + 300f * charge_ratio, 0.3f, 0.31f,
		                false, (int)AnimationState.AnimationAttackState.NONE);

		character_status.charge_value = 0;
		transform.root.GetComponent<Movement>().can_move = true;
	}
	
	public override void range_attack() {
		Movement movement = transform.GetComponent<Movement>();
		
		Vector3 launch_vector = new Vector3(2*x_axis, y_axis, 0).normalized;
		
		networkView.RPC("RPC_Range", RPCMode.All, "RangeAttackContainer", 15f, launch_vector, 30f, 1f, 0f, 1.6f, 0.4f, !movement.is_grounded);
	}
	
	public override void support_attack() {
		
		networkView.RPC("RPC_Melee", RPCMode.All, "HealAttackContainer", 20f, 1f, 0f, 0.5f, 0.75f,
		                false, (int)AnimationState.AnimationAttackState.NONE);
	}
}