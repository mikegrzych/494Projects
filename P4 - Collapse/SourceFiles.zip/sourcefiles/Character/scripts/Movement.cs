﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent (typeof (Rigidbody))]
public class Movement : MonoBehaviour {

	public bool is_grounded;
	public bool can_move;
	public bool was_hit;
	public const float jump_speed = 450f;
	public float jump_cooldown = 0f;
	public bool jump_toggle = false; 
	public const float change_direction_threshold = 0.02f;
	public int num_ground_collisions = 0;

	public float directional_influence = 0.55f;

	public bool waiting_to_leave_ground;

	public float original_angle;
			
	// Use this for initialization
	void Start () {
		
		is_grounded = false;
		was_hit = false;
		can_move = true;
		waiting_to_leave_ground = false;
		original_angle = transform.rotation.eulerAngles.y;
	}

	// Update is called once per frame
	void Update () {

		if (networkView.isMine) {

			CharacterStatus character_status = GetComponent<CharacterStatus>();

			//Get current position
			Vector3 velocity = rigidbody.velocity;

			//Get input
			float h_axis = GetComponent<CharacterController>().x_axis;
			
			//Update position
			if (can_move) {
				
				Animator temp_animator = GetComponent<AnimationState>().animator;
				if (!temp_animator.GetCurrentAnimatorStateInfo(0).IsTag("cannot_move")) {

					//Hit physics
					if (was_hit) {

						velocity.x += h_axis * character_status.character_stats.speed.real_stat * Time.deltaTime * directional_influence;
					}
					//Air movement is slightly slower
					else if (!is_grounded) {

						velocity.x = h_axis * character_status.character_stats.speed.real_stat * 0.9f;
					}
					else {

						velocity.x = h_axis * character_status.character_stats.speed.real_stat;
					}
				}
				else {

					velocity.x = 0;
				}
			}

			rigidbody.velocity = velocity;
			
			//If horizontal velocity changes change direction
			if ( h_axis > 0) {
				
				float tiltAngle = original_angle + 0.0f;
				Quaternion quaternion = Quaternion.Euler(new Vector3(0, tiltAngle, 0));
				transform.rotation = Quaternion.Slerp(transform.rotation, quaternion, 180);
			}
			
			//If horizontal velocity changes to reverse direction
			if ( h_axis < 0) {
				
				float tiltAngle = original_angle + 180.0f;
				Quaternion quaternion = Quaternion.Euler(new Vector3(0, tiltAngle, 0));
				transform.rotation = Quaternion.Slerp(transform.rotation, quaternion, 180);
			}

			//Check if player hit the ground after a hit
			if (was_hit && is_grounded && !waiting_to_leave_ground) {

				was_hit = false;
			}

			if(jump_toggle) {
				jump_cooldown -= Time.deltaTime;
			}

			// new groundedness (mike)
			RaycastHit hit_info;
			float dist = 2f;
			int layermask = 1 << 9;
			Vector3 offset = new Vector3(0f,0.5f,0f);
			Vector3 dir = new Vector3(0,-1,0);

			Vector3 left_edge = transform.position - new Vector3(collider.bounds.extents.x, 0f,0f) + offset;
			Vector3 right_edge = transform.position + new Vector3(collider.bounds.extents.x, 0f,0f) + offset;

			if(Physics.Raycast(right_edge, dir, out hit_info, dist, layermask) ||
			   Physics.Raycast(left_edge, dir, out hit_info, dist, layermask)){

				//print("raycast hit");
				if(!is_grounded){
					//print("hit ground");
					is_grounded = true;
					jump_cooldown = 0.25f;
					jump_toggle = true;
					networkView.RPC("RPC_Land",RPCMode.All);

					waiting_to_leave_ground = false;
				}
			} else {

				if(is_grounded){
//					print("leaving ground");
					is_grounded = false;
					jump_toggle = false;
					networkView.RPC("RPC_Jump",RPCMode.All);
				}

				if (waiting_to_leave_ground) {

					networkView.RPC("RPC_Hit", RPCMode.All);
					waiting_to_leave_ground = false;
				}
			}
		}
	}

	public void add_force(Vector3 force) {

		if (new Vector3(0,0,0).Equals(force)) {

			return;
		}

		print("Force of " + force.ToString() + " was added");
		rigidbody.velocity = new Vector3(0,0,0);
		rigidbody.AddForce(force);
		if(force.y > 0)
			waiting_to_leave_ground = true;
		was_hit = true;
	}

	public void jump() {

		if (is_grounded && jump_cooldown <= 0f ) {

			Vector3 velocity = new Vector3();
			Vector3 jumping_force = new Vector3();

			jumping_force.y =  jump_speed * rigidbody.mass;
			rigidbody.AddForce(jumping_force);
			is_grounded = false;
			velocity.x = 0;

			transform.rigidbody.velocity = velocity;
		}
	}

	[RPC]
	void RPC_AddForce(Vector3 force) {

		add_force(force);
	}

	[RPC]
	void RPC_Hit() {
		
		transform.Find("TrailRendererContainer").GetComponent<TrailRenderer>().enabled = true;
	}


	[RPC]
	void RPC_Jump() {
		GetComponent<AnimationState>().attack_state = AnimationState.AnimationAttackState.JUMPING;
	}
	
	[RPC]
	void RPC_Land() {
		GetComponent<AnimationState>().attack_state = AnimationState.AnimationAttackState.LANDING;
		is_grounded = true;
		waiting_to_leave_ground = false;
		transform.Find("TrailRendererContainer").GetComponent<TrailRenderer>().enabled = false;
	}

}


