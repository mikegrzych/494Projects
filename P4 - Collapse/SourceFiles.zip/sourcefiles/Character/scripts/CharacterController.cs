using UnityEngine;
using System.Collections;

public abstract class CharacterController : MonoBehaviour {

	//Get the directional axis
	public float x_axis {

		get {

			//Get controller input
			float temp = Input.GetAxis("L_XAxis_1");

			//Check if using keyboard
			if ( Mathf.Abs(Input.GetAxis("Vertical")) > Mathf.Abs(temp)) {
				
				temp = Input.GetAxis("Vertical");
			}

			return temp;
		}
	}

	public float y_axis {

		get {

			//Get controller input
			float temp = Input.GetAxis("L_YAxis_1");
			
			//Check if using keyboard
			if ( Mathf.Abs(Input.GetAxis("Horizontal")) > Mathf.Abs(temp)) {
				
				temp = Input.GetAxis("Horizontal");
			}
			
			return temp;
		}
	}

	//Xbox controller buttons
	protected XnControlState a_btn;
	protected XnControlState b_btn;
	protected XnControlState x_btn;
	protected XnControlState y_btn;
	protected XnControlState right_trigger;

	// Use this for initialization of subclass
	protected  abstract void init();

	// Update is called once per frame for subclass
	protected  abstract void update_loop();

	public abstract void standard_attack();

	public virtual void charge_attack() {}

	public abstract void range_attack();	
	
	public abstract void support_attack();
	
	[RPC]
	void RPC_ShieldOn() {
		Actions.activate_shield(transform);
	}

	[RPC]
	void RPC_ShieldOff() {
		Actions.deactivate_shield(transform);
	}

	[RPC]
	void RPC_Melee(string container_name, float damage, float priority, bool knockback, float duration,
	               float cooldown, bool is_airborn, int attack_animation) {
		Actions.melee_attack(transform, container_name, damage, priority, knockback, duration, cooldown, is_airborn);
		GetComponent<AnimationState>().attack_state = (AnimationState.AnimationAttackState)attack_animation;
	}
	
	[RPC]
	void RPC_Range(string container_name, float projectile_speed, Vector3 projectile_direction, float damage, float priority, bool knockback, float duration, float cooldown, bool is_airborn) {
		Actions.range_attack(transform, container_name, projectile_speed, projectile_direction, damage, priority, knockback, duration, cooldown, is_airborn);
	}

	// Update is called once per frame
	void Update() {

		//Restricts users so they only can control their character
		if (networkView.isMine) {

			CharacterStatus character_status = GetComponent<CharacterStatus>();
			Movement movement = GetComponent<Movement>();

			//Get controller input
			a_btn = XnUtils.XnGetXbox360Control(XnXboxControl.b_a);
			b_btn = XnUtils.XnGetXbox360Control(XnXboxControl.b_b);
			x_btn = XnUtils.XnGetXbox360Control(XnXboxControl.b_x);
			y_btn = XnUtils.XnGetXbox360Control(XnXboxControl.b_y);
			right_trigger = XnUtils.XnGetXbox360Control(XnXboxControl.rb);
						
			//Check if already attacking
			if (!character_status.is_attacking) {

				movement.can_move = true;

				//Uses character_status.charge_value
				if (movement.is_grounded && x_btn.up) {
					
					charge_attack();

					//reset charge value 
					character_status.charge_value = 0;
				}
				else if (Input.GetAxisRaw("Fire1") == 1 || x_btn.state) {
					
					standard_attack();
				}
				else {
					
					character_status.charge_value = 0;
	
					//Support attack controls
					if (Input.GetKeyDown(KeyCode.Q) || y_btn.down) {
						
						support_attack();
					}
					//Range attack controls
					else if (Input.GetAxisRaw("Fire2") == 1 || b_btn.state) {
						
						range_attack();
						movement.can_move = false;
					}
					//Shield on controls
					else if ( (right_trigger.down || Input.GetKey(KeyCode.E))) {

						//stop in your tracks
						if (movement.is_grounded) {

							Vector3 temp_velocity = transform.rigidbody.velocity;
							temp_velocity.x = 0;
							transform.rigidbody.velocity = temp_velocity;
						}

						movement.can_move = false;

						networkView.RPC("RPC_ShieldOn",RPCMode.All);
					}
				}
			}
			else {

				//Check if range attack button has been lifted
				if (!character_status.is_shielding && b_btn.up) {
					
					movement.can_move = true;
				}
			}

			//Shield off controls
			if (character_status.is_shielding && (right_trigger.up || Input.GetKeyUp(KeyCode.E))) {
				
				networkView.RPC("RPC_ShieldOff",RPCMode.All);
			}
			
			//Jump Controls
			if (Input.GetAxisRaw("Jump") == 1 || a_btn.down) {

				movement.jump();
			}
		}

		update_loop();
	}
}