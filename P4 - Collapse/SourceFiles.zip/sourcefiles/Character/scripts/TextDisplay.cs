﻿using UnityEngine;
using System.Collections;

public class TextDisplay : MonoBehaviour {

	static bool use_second_animation = false;
//	static Transform original_transform
	public Animator animator;

	public static bool orientation_set = false;
	public static Quaternion orientation;

	// Use this for initialization
	void Start () {

		if (!orientation_set) {

			TextDisplay.orientation = transform.rotation;
			orientation_set = true;
		}
	}

	public void Activate() {

		animator.enabled = true;
		if (TextDisplay.use_second_animation) {

			animator.Play("TextAnimation2");
			TextDisplay.use_second_animation = false;
		}
		else {

			animator.Play("TextAnimation");
			TextDisplay.use_second_animation = true;
		}
	}
	
	// Update is called once per frame
	void Update () {
	
		if (animator.GetCurrentAnimatorStateInfo(0).IsName("New State")) {

			Destroy( transform.gameObject);
		}
	}

	void LateUpdate() {

		transform.rotation = TextDisplay.orientation;
	}
}
