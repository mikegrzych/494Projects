﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

public class CharacterStatus : MonoBehaviour {

	private Vector2 barLoc;
	private Rect healthRect;
	private Rect backgroundRect;
	private Rect nameRect;
	private GUIStyle nameStyle;

	//Player Stats
	public float init_health = 500;
	public float init_attack = 50;
	public float init_speed = 10;
	public float init_offense_knockback = 100;
	public float init_defense_knockback = 100;

	public static List<CharacterStatus> total_characters = new List<CharacterStatus>();
	public Vector3 respawn_point;
	private TeamId team;
	private string _name;

	public string Name {
		get { return _name; }
		set { _name = value; }
	}

	public int team_number {
		get { return (int) team; }
	}
	public TeamId Team {
		get { return team; }
	}
	public BaseBehavior home_base;
	public Movement movement;
	public CharacterStats character_stats;

	public GameObject status_text;
	public Texture2D HealthBarBackground;

	//Health variables
	float max_hitpoints;
	float m_current_hitpoints;
	public float current_hitpoints {
	
		get {
			return m_current_hitpoints;
		}
		set {
		
			//Check if invulnerable
			if (is_invulnerable) return;

			SetCurrentHitpoints(value);
			networkView.RPC("RPC_SetCurrentHitpoints", RPCMode.All, value);
			print("current hitpoints: " + current_hitpoints);
		}
	}
	void SetCurrentHitpoints(float value) {

		float prev_value = m_current_hitpoints;


		//On health increase
		if (prev_value < value) {
	
			display_status( Mathf.Round(Mathf.Abs(value - prev_value)).ToString(), Color.green);
		}
		else if (prev_value > value) {

			display_status( Mathf.Round(Mathf.Abs(value - prev_value)).ToString(), Color.red);
		}

		if (value > max_hitpoints) {
			
			m_current_hitpoints = max_hitpoints;
		}
		else if (value < 0) {

			m_current_hitpoints = 0;
		}
		else {
			
			m_current_hitpoints = value;
		}
	}

	//Charge value
	Vector3 original_local_scale;
	public float max_charge_value = 3.0f;
	public float m_charge_value;
	public float charge_value {

		get {

			return m_charge_value;
		}
		set {

			if (value > max_charge_value) {

				m_charge_value = max_charge_value;
			}
			else if (value < 0) {

				m_charge_value = 0.0f;
			}
			else {

				m_charge_value = value;
			}

			transform.Find("ChargeMeter").transform.localScale = original_local_scale * (m_charge_value/max_charge_value);
		}
	}

	/// <summary>
	/// True if the player is invulnerable to damage
	/// </summary>
	public bool is_invulnerable;
	public bool is_attacking;
	public bool is_shielding;

	public bool is_facing_positive {

		get {

			float original_angle = movement.original_angle;

			return (this.transform.rotation.eulerAngles.y < original_angle + 90.0);
		}
	}

	public void SetName(string name_) {
		if (GetComponent<NetworkView>() != null)
			networkView.RPC("RPC_SetName",RPCMode.AllBuffered,name_);
	}

	void Start() {
		nameStyle = new GUIStyle("label");
		nameStyle.font = guiText.font;
		nameStyle.fontSize = 10 + Mathf.Max(0,(Screen.height - 600) / 50);
		nameStyle.alignment = TextAnchor.MiddleCenter;
	}

	// Use this for initialization
	void Awake () {

		is_invulnerable = false;
		is_attacking = false;
		is_shielding = false;
		charge_value = 0.0f;
		
		//ignore collision with other characters
		foreach (CharacterStatus temp_character in total_characters) {

			if (temp_character != null)
				Physics.IgnoreCollision(collider, temp_character.collider);
		}
		total_characters.Add(this);
		this.tag = "Player";

		character_stats = new CharacterStats( init_health, init_speed, init_offense_knockback, init_defense_knockback, init_attack);
		print("character stats: " + character_stats.ToString());
		max_hitpoints = character_stats.health.real_stat;
		current_hitpoints = max_hitpoints;

		original_local_scale = new Vector3(2.0f, 2.0f, 2.0f);
	}

	// Update is called once per frame
	void Update () {
			
		if (current_hitpoints <= 0 || transform.position.y < -5) {

			StartCoroutine(Respawn());
		}
	}

	void LateUpdate() {
		GUIContent temp = new GUIContent();
		temp.text = Name;

		Vector3 coordinates = gameObject.transform.position;
		coordinates.y += gameObject.collider.bounds.size.y;
		barLoc = Camera.main.WorldToScreenPoint(coordinates);
		float healthWidth = 50;//Screen.width * 0.15f;
		float height = 10;//Screen.height * 0.03f;
		backgroundRect = new Rect(barLoc.x - healthWidth/2, Screen.height - barLoc.y - height, healthWidth, height);
		float newWidth = healthWidth * current_hitpoints / max_hitpoints;
		healthRect = new Rect(barLoc.x - healthWidth/2, Screen.height - barLoc.y - height, newWidth, height);
		Vector2 nameSize = nameStyle.CalcSize(temp);
		nameRect = new Rect(barLoc.x - Mathf.Max(nameSize.x)/2, Screen.height - barLoc.y - (height*1.5f + Mathf.Max(nameSize.y)), Mathf.Max(nameSize.x), Mathf.Max(nameSize.y) + height*0.25f);
	}
	
	//Returns a list of hit boxes based on the players state
	public List<Hitbox> GetHitboxes() {
	
		List<Hitbox> result = new List<Hitbox>();
		
		foreach( Transform child in transform) {
			if (child.name == "Hurtbox")
				result.Add (child.GetComponent<Hurtbox>());
		}
		
		print( gameObject.name + " result: " + result.ToString());
		return result;
	}

	public int GetTeamNumber() {
		return team_number;
	}

	public void SetTeam(TeamId team) {

		this.team = team;

		SkinnedMeshRenderer skin = GetComponentInChildren<SkinnedMeshRenderer>();
		MeshRenderer mapIconColor = new MeshRenderer();
		MeshRenderer shieldColor = new MeshRenderer();
		MeshRenderer rangeColor = new MeshRenderer();
		foreach( Transform child in transform) {
			if (child.name == "MapIcon")
				mapIconColor = child.GetComponent<MeshRenderer>();
			else if(child.name == "Shield")
				shieldColor = child.GetComponent<MeshRenderer>();
			else if(child.name == "RangeAttackContainer")
				rangeColor = child.GetComponent<MeshRenderer>();
		}
		switch (team) {
		case TeamId.RED:
			skin.material.color = Color.red;
			mapIconColor.material.color = Color.red;
			shieldColor.material.color = Color.red;
			rangeColor.material.color = Color.red;
			break;
		case TeamId.BLUE:
			skin.material.color = Color.blue;
			mapIconColor.material.color = Color.blue;
			shieldColor.material.color = Color.blue;
			rangeColor.material.color = Color.blue;
			break;
		}

		if(home_base != null) {
			print("changing base... oops?");
		}
		home_base = BaseBehavior.FindBase(team);
		home_base.AddPlayerToTeam(this);
	}

	public void SetRespawnPoint(Vector3 rs) {
		respawn_point = rs;
	}

	// Recreates the player on screen
	public IEnumerator Respawn() {

		movement.enabled = false;
		
		yield return new WaitForSeconds(1.0f);			
		
		//set health back
		current_hitpoints = max_hitpoints;
				
		//set position
		transform.position = respawn_point;
		rigidbody.velocity = Vector3.zero;
		movement.enabled = true;

		//set respawn animation
		
	}

	/// <summary>
	/// Display the specified text in an animated status text.
	/// Requires character to have a 3D text along with TextDisplay on the game object.
	/// </summary>
	/// <param name="text">Text.</param>
	public void display_status(string text, Color color) {

		Transform status_text_object = (Transform)GameObject.Instantiate(status_text.transform);

		status_text_object.position = new Vector3(0,0,0);
		status_text_object.GetComponent<TextMesh>().text = text;
		status_text_object.GetComponent<TextMesh>().color = color;

		status_text_object.parent = status_text.transform.parent;

		status_text_object.GetComponent<TextDisplay>().Activate();
	}

	//___GUI___________________________________________
	void OnGUI() {

		GUI.color = ControlPointStatus.NEUTRAL_COLOR;
		GUI.DrawTexture(backgroundRect, HealthBarBackground, ScaleMode.StretchToFill);
		GUI.color = Color.green;
		GUI.DrawTexture(healthRect, HealthBarBackground, ScaleMode.StretchToFill);
		GUI.color = Color.white;
		GUI.Label(nameRect, Name, nameStyle);
	}

	//___RPC functions_________________________________

	[RPC]
	void RPC_SetTeamNumber(int n) {
		TeamId team = TeamUtils.GetTeam(n);
		SetTeam(team);
	}

	[RPC]
	void RPC_SetCurrentHitpoints(float hp) {
		
		SetCurrentHitpoints(hp);
	}

	[RPC]
	void RPC_SetName(string name_) {
		Name = name_;
		gameObject.name = name_;
	}
}
