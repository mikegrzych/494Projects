using UnityEngine;
using System.Collections;

public class Actions {

	/// <summary>
	/// Adds a melee attack for the character	
	/// </summary>
	/// <param name="transform">Transform of the attacking character</param>
	/// <param name="container_name">The name of the child attackbox of the character. GameObject must have a rigidbody and collider.</param>
	/// <param name="damage">Damage of the attack</param>
	/// <param name="priority">Priority, not currently implemented just pass 1.0f</param>
	/// <param name="knockback">Knockback force of the move</param>
	/// <param name="duration">Duration, how long move will last</param>
	/// <param name="cooldown">Cooldown, how long before the player can make their next attack</param>
	/// <param name="is_airborn">Should be passed as true if the character is airborn</param>
	public static void melee_attack(Transform transform, string container_name, float damage, float priority, bool knockback, float duration, float cooldown, bool is_airborn) {
	
		//Get character status for base stats for moves
		CharacterStatus character_status = transform.root.GetComponent<CharacterStatus>();	

		Transform original = Actions.get_child(transform, container_name);
		
		//Get Melee attackbox
		//Transform melee_object = (Transform) GameObject.Instantiate( original, original.position, original.rotation);
		//melee_object.parent = original.parent;
		//melee_object.renderer.enabled = true;
		//melee_object.name = "MeleeAttack";
		
		//Add Attackbox to attack
		Attack fire1 = new Attack(transform, damage + character_status.character_stats.base_damage.real_stat, 
		                          priority, knockback,
		                          duration, cooldown, is_airborn, character_status.team_number);
		original.GetComponent<Attackbox>().Activate( fire1);	
	}

	/// <summary>
	/// Adds a melee attack for the character	
	/// </summary>
	/// <param name="transform">Transform of the attacking character</param>
	/// <param name="container_name">The name of the child attackbox of the character. GameObject must have a rigidbody and collider.</param>
	/// <param name="projectile_speed">The speed of the projectile (20 is about average)</param>
	/// <param name="damage">Damage of the attack (Not including character base damage)</param>
	/// <param name="priority">Priority, not currently implemented just pass 1.0f</param>
	/// <param name="knockback">Knockback force of the move (Not including character attack knockback)</param>
	/// <param name="duration">Duration, how long move will last</param>
	/// <param name="cooldown">Cooldown, how long before the player can make their next attack</param>
	/// <param name="is_airborn">Should be passed as true if the character is airborn</param>
	public static void range_attack(Transform transform, string container_name, float projectile_speed, Vector3 projectile_direction,
	                                float damage, float priority, bool knockback, float duration, float cooldown, bool is_airborn) {

		//Get character status for base stats for moves
		CharacterStatus character_status = transform.root.GetComponent<CharacterStatus>();

		//Get Melee attackbox
		Transform range_object = (Transform) GameObject.Instantiate(transform.FindChild(container_name), transform.FindChild(container_name).position, transform.FindChild(container_name).rotation);
		range_object.renderer.enabled = true;
		range_object.name = "RangeAttack";

		//Add Attackbox to attack
		Attack fire1 = new Attack(transform, damage + character_status.character_stats.base_damage.real_stat,
		                          priority, knockback,
		                          duration, cooldown, is_airborn, character_status.team_number);
		range_object.GetComponent<Rangebox>().Activate( transform.gameObject, fire1);	

		//Add velocity to game object
		range_object.rigidbody.isKinematic = false;

		//Check if direction wasn't pressed
		if (projectile_direction == Vector3.zero) {

			if (transform.gameObject.GetComponent<CharacterStatus>().is_facing_positive) {
				
				projectile_direction = new Vector3(1, 0, 0);
			}
			else {
				
				projectile_direction = new Vector3(-1, 0, 0);
			}
		}

		projectile_direction = projectile_direction * projectile_speed;

		range_object.rigidbody.velocity = projectile_direction;
	}

	/// <summary>
	/// Activate shield of the specified character.
	/// </summary>
	/// <param name="transform">Transform of the character attempting to shield</param>
	public static void activate_shield(Transform transform) {

		transform.FindChild("Shield").GetComponent<Shieldbox>().Activate();
	}

	/// <summary>
	/// Deactivate shield of the specified character.
	/// </summary>
	/// <param name="transform">Transform of the character attempting to stop shielding</param>
	public static void deactivate_shield(Transform transform) {

		transform.FindChild("Shield").GetComponent<Shieldbox>().Deactivate();
	}

	public static Transform get_child(Transform parent, string child_name) {

		Transform[] children = parent.GetComponentsInChildren<Transform>();
		for(int i = 0; i < children.Length; i++) {

			if(children[i].name == child_name) {
			
				return children[i];
			}
		}

		return null;
	}
}
