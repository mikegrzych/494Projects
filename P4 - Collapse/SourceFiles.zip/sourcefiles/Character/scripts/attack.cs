﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Attack {
	
	//The damage done to the player
	float m_damage;
	public float damage {
		get {
			return m_damage;
		}
		set {
			if (value < 0)
				m_damage = 0;
			else
				m_damage = value;
		}
	}
	
	//What move takes presidence
	public float priority;
	
	//Should a force applied to the knockback
	public bool give_knockback;

	//Determins what direction the player should be knocked
	public bool to_be_knocked_backwards;

	//The duration of the move
	public float duration;

	//The cooldown before you can attack
	public float attack_cooldown;

	//The team the attack belongs to
	public int team_number;
	
	//returns true if the attack is an airborn attack
	public bool is_airborn;
	
	//Array of CharacterStatus that have been affected by the attack
	public List<CharacterStatus> affected_characters;
	public List<DestructableStatus> affected_objects;
	
	public Attack(Transform character_transform, float in_damage, float in_priority, bool in_give_knockback,
	              float in_duration, float in_attack_cooldown, bool in_is_airborn, int in_team_number) {
	
		damage = in_damage;
		priority = in_priority;
		give_knockback = in_give_knockback;
		duration = in_duration;
		attack_cooldown = in_attack_cooldown;
		is_airborn = in_is_airborn;
		team_number = in_team_number;

		//calculate the knockback direction
		to_be_knocked_backwards = (character_transform.rotation.eulerAngles.y > 170.0);

		affected_characters = new List<CharacterStatus>();
		affected_objects = new List<DestructableStatus>();
	}
		
	//The angle of the knockback (radians)
	public float get_kb_angle(float current_knockback) {
	
		//Sakurai angle for Super Smash Brawl
		float result;
		
		//check if airborn
		if (is_airborn) {
		
			//45 degrees converted to radians
			result = 40 * Mathf.PI / 180;
		}
		else if (current_knockback > 60) {
		
			//37 degrees converted to radians
			result = 70 * Mathf.PI / 180;			
		}
		else {
		
			result = 0;
		}

		//figure out what direction to hit the player
		if (to_be_knocked_backwards) {
			
			result = Mathf.PI - result;
		}

		return result;
	}

	//The magnitude of the knockback (radians)
	public float get_kb_magnitude() {

		float min_damage = 100f;
		float max_damage = 250f;
		float min_knockback = 700f;
		float max_knockback = 1500f;

		//return 0 if the knockback is set to 0
		if (!give_knockback)
			return 0;

		//magnitude
		float result;
		
		//Apply limits
		if (damage > max_damage) {

			result = max_knockback;
		}
		else if (damage < min_damage) {

			result = min_knockback;
		}
		else {

			result = min_knockback + (max_knockback - min_knockback) * ((damage - min_damage) / max_damage);
		}

		return result;
	}
}
