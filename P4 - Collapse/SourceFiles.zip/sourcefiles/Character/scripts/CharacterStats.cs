﻿using System.Collections;

public class CharacterStats {

	public class Stat {

		float min_stat;
		float max_stat;
		float m_stat;
		float m_stat_percent;
		public float relative_stat {
			
			get {
				
				return m_stat_percent;
			}
			set {
				
				if (value > 100) {

					m_stat_percent = 100;
				}
				else if (value < 100) {
					
					m_stat_percent = 100;
				}
				else {

					m_stat_percent = value;
				}
			}
		}

		public float real_stat {
			
			get {
				
				return m_stat * m_stat_percent;
			}
			set {
				
				if (value > max_stat) {
					
					m_stat_percent = max_stat / m_stat;
				}
				else if (value < min_stat) {
					
					m_stat_percent = min_stat / m_stat;
				}
				else {
					
					m_stat_percent = value / m_stat;
				}
			}
		}

		public Stat(float min, float max, float in_stat_value) {

			min_stat = min;
			max_stat = max;
			m_stat = in_stat_value;
			m_stat_percent = 1.0f;
		}
	}

	public Stat health;
	public Stat speed;
	public Stat attack_knockback;
	public Stat defense_knockback;
	public Stat base_damage;

	/// <summary>
	/// Initializes a new instance of the <see cref="CharacterStats"/> class.
	/// Keeps track of the health, speed, attack knockback, defense knockback, and base damage stats.
	/// </summary>
	/// <param name="in_health">Health of the character. Min: 100 Max: 500</param>
	/// <param name="in_speed">Speed the character moves. Min: 8 Max: 12</param>
	/// <param name="in_attack_knockback">The base knockback of player attacks. Min: 0 Max: 1000</param>
	/// <param name="in_defense_knockback">The knockback reduced by the player when taking a hit. Min: 0 Max: 1000</param>
	/// <param name="in_base_damage">The base damage of a players attack. Min: 20 Max: 200</param>
	public CharacterStats(float in_health, float in_speed, float in_attack_knockback, float in_defense_knockback, float in_base_damage) {

		health = new Stat(100, 500, in_health);
		speed = new Stat(8, 12, in_speed);
		attack_knockback = new Stat(0, 1000, in_attack_knockback);
		defense_knockback = new Stat(0, 1000, in_defense_knockback);
		base_damage = new Stat(20, 200, in_base_damage);
	}
}
