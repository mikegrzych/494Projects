﻿using UnityEngine;
using System.Collections;

public class AnimationState : MonoBehaviour {

	public Animator animator;

	//Attack variables
	public enum AnimationAttackState { NONE, STANDARD, RUNNING, AIRBORNE, JUMPING, LANDING};
	public AnimationAttackState attack_state;

	// Use this for initialization
	void Start () {
	
		attack_state = AnimationAttackState.NONE;
		animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
	
		Movement movement = GetComponent<Movement>();
		CharacterStatus character_status = GetComponent<CharacterStatus>();

		//Check if player is dead
		if (character_status.current_hitpoints <= 0) {

			attack_state = AnimationAttackState.NONE;
			animator.SetBool("die", true);
			return;
		}
		else {

			animator.SetBool("die", false);
		}

		//Check if player was hit
/*		if (movement.was_hit) {

			animator.SetBool("hit", true);
		}
		else {

			animator.SetBool("hit", false);
		}
*/

		//Check what attack player is doing
		if (attack_state == AnimationAttackState.STANDARD) {

			animator.SetBool("standard_attack", true);
		}
		else {

			animator.SetBool("standard_attack", false);
		}

		if (attack_state == AnimationAttackState.RUNNING) {

			animator.SetBool("running_attack", true);
		}
		else {

			animator.SetBool("running_attack", false);
		}

		if (attack_state == AnimationAttackState.AIRBORNE) {

			animator.SetBool("airborne_attack", true);
		}
		else {

			animator.SetBool("airborne_attack", false);
		}

		//Check if player is running
		if ( Mathf.Abs( rigidbody.velocity.x) > 0 &&
		    movement.is_grounded) {

			animator.SetBool("run", true);
		}
		else {

			animator.SetBool("run", false);
		}

		if( attack_state == AnimationAttackState.JUMPING) {
			animator.SetBool("jump", true);
		}

		if( attack_state == AnimationAttackState.LANDING) {
			animator.SetBool("jump", false);
		}
		//Reset animation state
		attack_state = AnimationAttackState.NONE;
	}
}
