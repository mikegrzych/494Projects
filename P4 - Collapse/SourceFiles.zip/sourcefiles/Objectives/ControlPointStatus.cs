﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ControlPointEvent {
	public TeamId OldController;
	public TeamId NewController;
}

public class ControlPointStatus : MonoBehaviour {

	public enum DisplayLocation { LEFT, MIDDLE, RIGHT };

	public DisplayLocation Location;
	public ScreenInfo ScreenSizeInfo;
	public Texture2D HUDTexture;
	public GUISkin HUDSkin;


	public List<CharacterStatus> occupied_by = new List<CharacterStatus>();
	public int TotalDirection; //we add -1 or 1 for every team 0 or team 1 player, respectively
	public bool IsNeutral;
	public const float TimeToControl = 5;
	public const float PointsScalar = 1f; // in case one control point is worth more, e.g.

	public TeamId LeaningTowards {
		get { return ControlMeter < 0 ? TeamId.RED : TeamId.BLUE; }

	}


	private TeamId _controller;
	public TeamId ControlledBy {
		get { return _controller; }
	}
	private float ControlMeter;
	private float OldControlMeter;

	//public int ZoneIndex; // this needs to be set in the level.

	private List<GameObject> listeners = new List<GameObject>();

	private Dictionary<TeamId, int> PlayersPerTeam = new Dictionary<TeamId, int>();

	public int NumRedTeamPlayers {
		get { return PlayersPerTeam[TeamId.RED]; }
		set { PlayersPerTeam[TeamId.RED] = value; }
	}

	public int NumBlueTeamPlayers {
		get { return PlayersPerTeam[TeamId.BLUE]; }
		set { PlayersPerTeam[TeamId.BLUE] = value; }
	}

	public static Color RED_TEAM_COLOR = new Color(1.0f, 0.0f, 0.0f, 0.5f);
	public static Color NEUTRAL_COLOR = new Color(0.5f, 0.5f, 0.5f, 88.0f / 256.0f);
	public static Color BLUE_TEAM_COLOR = new Color(0.0f, 0.0f, 1.0f, 0.5f);
	public static Color BACKGROUND_COLOR = new Color(0.345f, 0.345f, 0.345f, 1.0f);

	public GameObject Flag;

	void Awake() {
		NumRedTeamPlayers = NumBlueTeamPlayers = 0;
	}
	
	// Use this for initialization
	void Start() {
		ControlMeter = 0;
		OldControlMeter = 0;
		TotalDirection = 0;
		_controller = TeamId.NEUTRAL;
		BroadcastMessage("UpdateTeam",ControlledBy,SendMessageOptions.DontRequireReceiver);
	}
	
	// Update is called once per frame
	void Update () {
		CalculateControl ();
		UpdateZoneColor();
	}
	
	void OnTriggerEnter(Collider collider) {
		
		if ("Player" == collider.gameObject.tag) {
			CharacterStatus cs = collider.gameObject.GetComponent<CharacterStatus>();
			TeamId team = cs.Team;
			PlayersPerTeam[team] += 1;

			if(NumRedTeamPlayers > 0 && NumBlueTeamPlayers == 0) {
				TotalDirection = -1;
			} else if (NumBlueTeamPlayers > 0 && NumRedTeamPlayers == 0) {
				TotalDirection = 1;
			} else {
				TotalDirection = 0;
			}

			print("#red: "+NumRedTeamPlayers+"\n#blue: "+NumBlueTeamPlayers);
			print("dir: "+TotalDirection);
		}		
    }
	
	void OnTriggerExit(Collider collider) {
	
		if ("Player" == collider.gameObject.tag) {
			CharacterStatus cs = collider.gameObject.GetComponent<CharacterStatus>();
			TeamId team = cs.Team;
			PlayersPerTeam[team] -= 1;
			
			if(NumRedTeamPlayers > 0 && NumBlueTeamPlayers == 0) {
				TotalDirection = -1;
			} else if (NumBlueTeamPlayers > 0 && NumRedTeamPlayers == 0) {
				TotalDirection = 1;
			} else {
				TotalDirection = 0;
			}
			
			print("#red: "+NumRedTeamPlayers+"\n#blue: "+NumBlueTeamPlayers);
			print("dir: "+TotalDirection);
		}
	}
	
	void CalculateControl() {
		OldControlMeter = ControlMeter;
		if(TotalDirection > 0) {
			ControlMeter += Time.deltaTime;
		} else if (TotalDirection < 0) {
			ControlMeter -= Time.deltaTime;
		}
		
		//control_meter -= Time.deltaTime / 2; //REMOVE THIS. JUST FOR TESTING
		
		ControlMeter = Mathf.Max(-1*TimeToControl, ControlMeter);
		ControlMeter = Mathf.Min (TimeToControl, ControlMeter);
		TeamId oldController = _controller;
		if (ControlMeter == TimeToControl) {
			_controller = TeamId.BLUE;
			UpdateFlagColor();
			BroadcastMessage("UpdateTeam",ControlledBy,SendMessageOptions.DontRequireReceiver);
		} else if (ControlMeter == -1 * TimeToControl) {
			_controller = TeamId.RED;
			UpdateFlagColor ();
			BroadcastMessage("UpdateTeam",ControlledBy,SendMessageOptions.DontRequireReceiver);
		}
		if ((OldControlMeter < 0 && ControlMeter >= 0) || (OldControlMeter > 0 && ControlMeter <= 0)) { 
			//this means control_meter crossed zero
			_controller = TeamId.NEUTRAL;
			UpdateFlagColor ();
			BroadcastMessage("UpdateTeam",ControlledBy,SendMessageOptions.DontRequireReceiver);
		}

		if (oldController != _controller) {
			NotifyListeners(oldController, _controller);
		}
	}

	void UpdateFlagColor() {
		Flag.renderer.material.color = GetColorForTeam(ControlledBy);
	}

	Color GetColorForTeam(TeamId team) {
		switch (team) {
		case TeamId.RED:
			return RED_TEAM_COLOR;
		case TeamId.BLUE:
			return BLUE_TEAM_COLOR;
		default:
			return NEUTRAL_COLOR;
		}
	}

	void UpdateZoneColor() {
		if(TotalDirection > 0.05) {
			renderer.material.color = BLUE_TEAM_COLOR;
		} else if (TotalDirection < -0.05) {
			renderer.material.color = RED_TEAM_COLOR;
		} else {
			renderer.material.color = NEUTRAL_COLOR;
		}
	}

	Rect CalculateRect(bool scaled = true) {
		float percentControlled = Mathf.Abs(ControlMeter) / TimeToControl;
		float top = ScreenSizeInfo.VerticalGrid[8];
		float left;
		switch (Location) {
		case DisplayLocation.LEFT:
			left = ScreenSizeInfo.HorizontalGrid[2];
			break;
		case DisplayLocation.MIDDLE:
			left = ScreenSizeInfo.HorizontalGrid[5];
			break;
		case DisplayLocation.RIGHT:
			left = ScreenSizeInfo.HorizontalGrid[8];
			break;
		default:
			// Should not reach
			left = 0;
			break;
		}
		float width = scaled ? ScreenSizeInfo.TenthHorizontal * percentControlled : ScreenSizeInfo.TenthHorizontal;
		float height = scaled ? ScreenSizeInfo.TenthVertical * percentControlled : ScreenSizeInfo.TenthVertical;
		left -= 0.5f * width;
		top += 0.5f * (ScreenSizeInfo.TenthVertical - height);
		Rect r = new Rect(left, top, width, height);
		return r;
	}

	void OnGUI() {
		GUI.skin = HUDSkin;
		Rect r = CalculateRect();
		Rect back = CalculateRect(false);
		//GUILayout.BeginArea(r);
		GUI.color = BACKGROUND_COLOR;
		GUI.DrawTexture(back, HUDTexture, ScaleMode.ScaleToFit);
		GUI.color = GetColorForTeam(LeaningTowards);
		GUI.DrawTexture(r, HUDTexture, ScaleMode.ScaleToFit);
		GUI.color = Color.white;
		//GUILayout.Label(ControlledBy.ToString());
		//GUILayout.EndArea();
	}

	void RegisterForControlEvent(GameObject go) {
		listeners.Add(go);
	}

	private void NotifyListeners(TeamId former, TeamId current) {
		print("Notify");
		ControlPointEvent cpe = new ControlPointEvent();
		cpe.OldController = former;
		cpe.NewController = current;
		foreach (GameObject go in listeners) {
			go.SendMessage("OnControlPointStatus", cpe);
		}
	}

}
