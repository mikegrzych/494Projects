﻿using UnityEngine;
using System.Collections;

public class FlagStatus : MonoBehaviour {

	private Color team_0_color = new Color(1.0f, 0.5f, 0.5f, 0.5f);
	private Color neutral_color = new Color(0.5f, 0.5f, 0.5f, 0.5f);
	private Color team_1_color = new Color(0.5f, 0.5f, 1.0f, 0.5f);

	ControlPointStatus cps;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
