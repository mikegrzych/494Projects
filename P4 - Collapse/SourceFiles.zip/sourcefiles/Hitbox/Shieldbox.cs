﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Shieldbox : Hitbox {

	public float MAX_PRIORITY = 2.5f;
	public float priority;
	public float MAX_SHIELD_TIME = 3.0f;

	public float max_damage_reduce = 100.0f;
	public float percent_reduced = 0.4f;
	public float min_damage_reduce = 60.0f;

	//time left to keep shield active
	public float m_time_left;
	protected float time_left {

		get {

			return m_time_left;
		}
		set {

			if (value > MAX_SHIELD_TIME) {

				m_time_left = MAX_SHIELD_TIME;
			}
			else if (value < 0) {

				m_time_left = 0f;
			}
			else {

				m_time_left = value;
			}

			transform.root.Find("Shield").transform.localScale = new Vector3(0.5f,0.5f,0.5f) + new Vector3(1.5f,1.5f,1.5f) * (m_time_left/MAX_SHIELD_TIME);
		}
	}

	/// <summary>
	/// Wether the shield is active/deployed.
	/// </summary>
	public bool is_active;

	// Use this for initialization
	void Start () {

		Deactivate();
	}
	
	// Update is called once per frame
	void Update () {
		
		//Check if Attackbox is activated
		if (is_active) {
			
			//update time left
			time_left -= Time.deltaTime;

			//update priority value
			priority -= Time.deltaTime;

			//Check if attack duration finished
			if (time_left <= 0) {
				
				//remove the collider if enabled to remove effects by the box
				Deactivate();
			}
		}
		else {

			//Recovery time is half the drain time
			time_left += Time.deltaTime;
		}
	}
	
	//Activate
	public void Activate() {

		is_active = true;
		transform.collider.enabled = true;
		transform.renderer.enabled = true;
		transform.root.GetComponent<CharacterStatus>().is_attacking = true;
		//transform.root.GetComponent<CharacterStatus>().is_invulnerable = true;
		transform.root.GetComponent<CharacterStatus>().is_shielding = true;

		priority = MAX_PRIORITY;
		time_left -= 0.3f;
	}

	//De-Activate
	public void Deactivate() {
		
		is_active = false;
		transform.collider.enabled = false;
		transform.renderer.enabled = false;
		transform.root.GetComponent<CharacterStatus>().is_attacking = false;
		//transform.root.GetComponent<CharacterStatus>().is_invulnerable = false;
		transform.root.GetComponent<CharacterStatus>().is_shielding = false;
	}
	
	//Effect the certain hitbox will perform
	public override void Effect(Hitbox hitbox) {

		//do nothing
	}
}
