﻿using UnityEngine;
using System.Collections;

public class MovingDamagebox : Attackbox {
	
	// Update is called once per frame
	void Update () {
	
		//Check if Attackbox is activated
		if (attack != null) {

			//Attack priority stays constant
			//update priority value
			//attack.priority -= Time.deltaTime;
			
			//Check if attack duration finished
			if (get_owner().GetComponent<Movement>().is_grounded && !get_owner().GetComponent<Movement>().waiting_to_leave_ground) {
				
				Deactivate();
			}			
		}
	}
}
