﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Attackbox : Hitbox {

	//This should be a move effect
	public MoveEffect move_effect;

	public Attack attack;
	protected float time_left;
	protected bool attack_on_cooldown;
	protected const float SHIELD_KNOCKBACK_FACTOR = 0.5f;

	//Constructor
	public Attackbox() :
	base() {
		
		attack = null;
		time_left = 0;
		attack_on_cooldown = false;
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
		//Check if Attackbox is activated
		if (attack != null) {
			
			//update time left
			time_left -= Time.deltaTime;

			//update priority value
			attack.priority -= Time.deltaTime;

			//Check if attack duration finished
			if (time_left < 0) {
			
				//remove the collider if enabled to remove effects by the box
				if (gameObject.collider.enabled) {

					transform.renderer.enabled = false;
					gameObject.collider.enabled = false;
				}

				//Don't destory unless the attack cooldown has reset
				if (!attack_on_cooldown) {
	
					Deactivate();
					return;
				}
			}

			if (attack_on_cooldown && (time_left - attack.duration + attack.attack_cooldown) < 0) {

				transform.root.GetComponent<CharacterStatus>().is_attacking = false;
				attack_on_cooldown = false;
			}
		}
	}
				
	//Activate
	public virtual void Activate(Attack in_attack) {

		//make game object appear
		renderer.enabled = true;
		collider.enabled = true;

		attack = in_attack;
		time_left = attack.duration;
		attack_on_cooldown = true;
		transform.root.GetComponent<CharacterStatus>().is_attacking = true;

		//activate move effect
		move_effect.activate(this);
	}

	public virtual void Deactivate() {

		//Stop drawing game object
		renderer.enabled = false;
		collider.enabled = false;

		attack = null;
		time_left = 0;
		attack_on_cooldown = false;
		transform.root.GetComponent<CharacterStatus>().is_attacking = false;

		//deactivate move effect
		move_effect.deactivate(this);
	}

	//Effect the certain hitbox will perform
	public override void Effect(Hitbox hitbox) {

		//Check if Attackbox is activated
		if (attack == null) return;

		//Check if the hurtbox does not belongs to you
		if (hitbox.get_owner().GetComponent<NetworkView>() == null || !hitbox.get_owner().networkView.isMine) {

			print("Player: " + hitbox.get_owner().name + " hit was ignored");
			return;
		}

		if (hitbox is DestructableHurt) {
			//Get target
			DestructableStatus target = ((DestructableHurt)hitbox).target_status;
			print("hit a block");

			//Check if hit is valid
			if (!can_hit_target (target)) {
				return;
			}

			//reduce health
			target.current_hitpoints -= attack.damage;
			print("did " + attack.damage + " to block");

			//give knockback if applicable
//			if (target.current_hitpoints <= 0) {
//				float knockback_angle = attack.get_kb_angle(attack.damage);
//				apply_knockback (attack.knockback_magnitude * 10f, knockback_angle, target);
//			}

			attack.affected_objects.Add(target);
		}

		Attackbox opp_attack = hitbox as Attackbox;
		if (opp_attack != null && opp_attack.attack != null) {

			//Get attack
			//Attack opp_attack = ((Attackbox)hitbox).attack;

			if (opp_attack.attack.priority > attack.priority) {

				print("your attack was cancelled by " + hitbox.get_owner().name + "'s attack");

				Deactivate();
				return;
			}
		}

		if (hitbox is Hurtbox) {

			//Get target
			CharacterStatus target = ((Hurtbox)hitbox).character_status;
				
			//Check if the hit is valid
			if (!can_hit_target(target) || target.is_shielding) {
				
				return;
			}

			//Check if colliding with the players shield
			if (is_shielding_attack(target)) {

				return;
			}

			print("dealing " + attack.damage + " to " + hitbox.get_owner().name);
											
			//reduce health
			((MoveEffect)move_effect).action(this, target);

			//give knockback
			float knockback_angle = attack.get_kb_angle(attack.damage);
			apply_knockback( attack.get_kb_magnitude(), knockback_angle, target);

			attack.affected_characters.Add(target);

			get_owner().audio.Play();
		}

		if (hitbox is Shieldbox) {

			//Cast to shieldbox
			Shieldbox shieldbox = (Shieldbox)hitbox;

			//Get target
			CharacterStatus target = shieldbox.get_owner().GetComponent<CharacterStatus>();

			//Check if the hit is valid
			if (!can_hit_target(target)) {

				return;
			}
			
			print("hitting shield of " + hitbox.get_owner().name);

			//check priority
			if (shieldbox.priority > attack.priority) {

				hitbox.get_owner().GetComponent<CharacterStatus>().display_status("Good Shield", Color.cyan);

				//reduce damage by max and percentage
				attack.damage = (attack.damage - shieldbox.max_damage_reduce) * (1.0f - shieldbox.percent_reduced);
			}
			else {

				//reduce damage by min
				attack.damage = attack.damage - shieldbox.min_damage_reduce;
			}

			//reduce health
			((MoveEffect)move_effect).action(this, target);

			//give knockback
			float knockback_angle = attack.get_kb_angle(attack.damage);
			apply_knockback( attack.get_kb_magnitude(), knockback_angle, target);

			attack.affected_characters.Add(target);

//Play shield audio______________________________________________________
			get_owner().audio.Play();
		}
	}

	/// <summary>
	/// Returns if attackbox can hit target the specified target.
	/// </summary>
	/// <param name="target">Target.</param>
	protected virtual bool can_hit_target(CharacterStatus target) {

		//Check if player is on team
		if (target.team_number == attack.team_number) {
			
			return false;
		}
		
		//Check if already hit
		foreach (CharacterStatus hit_character in attack.affected_characters) {
			
			if (hit_character == target) {
				
				return false;
			}
		}
		return true;
	}

	protected bool can_hit_target(DestructableStatus target) {
		
		//Check if already hit
		foreach (DestructableStatus hit_object in attack.affected_objects) {
			
			if (hit_object == target) {
				
				return false;
			}
		}
		return true;
	}

	/// <summary>
	/// Applyies knockback given the specified mag and angle to the target.
	/// </summary>
	/// <param name="mag">Mag.</param>
	/// <param name="angle">Angle.</param>
	/// <param name="target">Target.</param>
	void apply_knockback(float mag, float angle, CharacterStatus target) {

		Vector3 knockback_force = new Vector3();

		float knockback_magnitude = mag - target.character_stats.defense_knockback.real_stat;
		if (knockback_magnitude <= 0) {
			
			knockback_magnitude = 0;
		}
		
		knockback_force.x = knockback_magnitude * Mathf.Cos( angle);
		knockback_force.y = knockback_magnitude * Mathf.Sin( angle);
		target.transform.root.GetComponent<Movement>().add_force(knockback_force);
	}

	/// <summary>
	///Check if colliding with the players shield
	/// </summary>
	/// <param name="target">Target.</param>
	bool is_shielding_attack(CharacterStatus target) {

		Transform shield = Actions.get_child(target.transform.root, "Shield");
		print("is shield active: " + shield.GetComponent<Shieldbox>().is_active);
		print ("is collision occuring: " + collider.bounds.Intersects(shield.collider.bounds));
		if (shield.GetComponent<Shieldbox>().is_active && collider.bounds.Intersects(shield.collider.bounds)) {
			
			print("shielded attack");
			return true;
		}
		return false;
	}
}
