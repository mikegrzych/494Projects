﻿using UnityEngine;
using System.Collections;

public class BasicDamage : MoveEffect {

	public override void activate(object in_class) {}
	public override void deactivate(object in_class) {}

	public override void action(object in_class, CharacterStatus target) {

		Attackbox attack_box = ((Attackbox)in_class);
		target.current_hitpoints -= attack_box.attack.damage;
	}
}
