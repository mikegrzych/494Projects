﻿using UnityEngine;
using System.Collections;

public class PlayerPush : MoveEffect {
	
	CharacterController controls;
	public float throw_mag = 500;

	// Use this for initialization
	void Start () {

		controls = transform.root.GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {

	}
	
	public override void activate(object in_class) {}
	
	public override void deactivate(object in_class) {}
	
	public override void action(object in_class, CharacterStatus target) {

		((Attackbox)in_class).Deactivate();
		
		//Get directional vector
		Vector3 throw_vector;
		bool is_facing_right = ((Attackbox)in_class).get_owner().GetComponent<CharacterStatus>().is_facing_positive;
		
		if (is_facing_right) {
			
			throw_vector = new Vector3(0.3f, 1f, 0);
		}
		else {
			
			throw_vector = new Vector3(-0.3f, 1f, 0);
		}
		throw_vector.Normalize();
		throw_vector = throw_vector * throw_mag;

		//Display message to player
		target.display_status("Thrown", Color.cyan);

		target.networkView.RPC("RPC_AddForce", RPCMode.All, throw_vector);
			//GetComponent<Movement>().add_force(throw_vector);
		
		//Add Attackbox onto another player
		//Duration is not needed because it deactivates on ground collision
		target.networkView.RPC("RPC_Melee", RPCMode.All, "ThrownAttackContainer", 150f, 3f, true, 0.0f, 0.0f,
		                                  false, (int)AnimationState.AnimationAttackState.NONE);
	}
}

