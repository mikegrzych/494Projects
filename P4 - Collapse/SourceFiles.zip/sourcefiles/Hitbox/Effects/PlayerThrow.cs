﻿using UnityEngine;
using System.Collections;

public class PlayerThrow : MoveEffect {

	CharacterController controls;
	public float throw_mag = 400;

	public enum ThrowState { EMPTY, HOLDING_PLAYER};

	public ThrowState throw_state;
	public GameObject held_player;
	
	// Use this for initialization
	void Start () {
	
		held_player = null;
		throw_state = ThrowState.EMPTY;
		controls = transform.root.GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {
	
		if (held_player != null) {

			//Determine the offset to hold the character
			Vector3 offset;
			bool is_facing_right = transform.root.GetComponent<CharacterStatus>().is_facing_positive;
			if (is_facing_right) {
				
				offset = new Vector3( 1, 0, 1);
			}
			else {
				
				offset = new Vector3( -1, 0, 1);
			}

			held_player.transform.position = transform.root.position + offset;
			held_player.rigidbody.velocity = transform.root.rigidbody.velocity;
		}
	}

	public override void activate(object in_class) {

		if (throw_state == ThrowState.HOLDING_PLAYER) {
			
			((Attackbox)in_class).Deactivate();

			//Get directional vector
			Vector3 throw_vector;
			bool is_facing_right = ((Attackbox)in_class).get_owner().GetComponent<CharacterStatus>().is_facing_positive;
			
			if (is_facing_right) {
				
				throw_vector = new Vector3(1, 1, 0);
			}
			else {
				
				throw_vector = new Vector3(-1, 1, 0);
			}
			throw_vector.Normalize();
			throw_vector = throw_vector * throw_mag;
			
			held_player.GetComponent<Movement>().add_force(throw_vector);
			
			throw_state = ThrowState.EMPTY;
			
			release_player();
			
			//Display message to player
			held_player.GetComponent<CharacterStatus>().display_status("Thrown", Color.cyan);
		}
	}

	public override void deactivate(object in_class) {}

	public override void action(object in_class, CharacterStatus target) {

		if (throw_state == ThrowState.EMPTY) {

			pick_up_player(target.gameObject);
			throw_state = ThrowState.HOLDING_PLAYER;

			//Display message to player
			target.display_status("Grabbed", Color.cyan);
		}
	}

	void pick_up_player(GameObject player) {

		held_player = player;

		CharacterStatus player_status = player.GetComponent<CharacterStatus>();

		//cannot take damage
		player_status.is_invulnerable = true;

		//cannot make moves
		player_status.is_attacking = true;

		//cannot move
		player.GetComponent<Movement>().can_move = false;
	}

	void release_player() {

		CharacterStatus player_status = held_player.GetComponent<CharacterStatus>();

		//reset values
		player_status.is_invulnerable = false;
		player_status.is_attacking = false;
		held_player.GetComponent<Movement>().can_move = true;

		held_player = null;
	}
}
