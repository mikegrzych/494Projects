﻿using UnityEngine;
using System.Collections;

public abstract class MoveEffect : MonoBehaviour {

	public abstract void activate(object in_class);
	public abstract void deactivate(object in_class);
	public abstract void action(object in_class, CharacterStatus target);
}
