﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Rangebox : Attackbox {
	
	public GameObject attack_owner;
	public bool original_box = true;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		//Check if Attackbox is activated
		if (attack != null) {
			
			//update time left
			time_left -= Time.deltaTime;

			//update priority value
			attack.priority -= Time.deltaTime;

			//Check if attack duration finished
			if (time_left < 0 || attack.affected_objects.Count > 0) {
				
				//remove the collider if enabled to remove effects by the box
				if (gameObject.collider.enabled) {
					
					gameObject.collider.enabled = false;
					gameObject.renderer.enabled = false;
				}
				
				//Don't destory unless the attack cooldown has reset
				if (!attack_on_cooldown) {

					//deactivate move effect
					move_effect.deactivate(this);
					DestroyObject(gameObject);
				}
			}

			if (attack_on_cooldown && (time_left - attack.duration + attack.attack_cooldown) < 0) {

				attack_owner.transform.GetComponent<CharacterStatus>().is_attacking = false;
				attack_on_cooldown = false;
			}
		}
	}


	public override void OnTriggerEnter(Collider in_collider) {

		//Don't have collisions with original
		if (original_box) return;

		//Disappear once box hits the ground
		if ("Ground" == in_collider.gameObject.tag) {

			gameObject.collider.enabled = false;
			gameObject.renderer.enabled = false;
			return;
		}
		base.OnTriggerEnter(in_collider);
	}

	//Activate
	public void Activate(GameObject in_attack_owner, Attack in_attack) {

		//Set object reference to owner
		attack_owner = in_attack_owner;

		original_box = false;

		attack = in_attack;
		time_left = attack.duration;
		attack_on_cooldown = true;
		attack_owner.GetComponent<CharacterStatus>().is_attacking = true;

		//activate move effect
		move_effect.activate(this);
	}

	/// <summary>
	/// Returns if attackbox can hit target the specified target.
	/// </summary>
	/// <param name="target">Target.</param>
	bool can_hit_target(CharacterStatus target) {

		//check if collision is not with player hitboxes
		if (attack_owner == target.transform.root.gameObject) {			
			
			return false;
		}

		bool attackbox_result = base.can_hit_target(target);

		return attackbox_result;
	}

	bool is_shielding_attack(CharacterStatus target) {
		
		Transform shield = Actions.get_child(target.transform.root, "Shield");
		if (shield.GetComponent<Shieldbox>().is_active && collider.bounds.Intersects(shield.collider.bounds)) {
			
			print("shielded range attack");
			return true;
		}
		return false;
	}

	public override GameObject get_owner() {
		
		return attack_owner;
	}
}

