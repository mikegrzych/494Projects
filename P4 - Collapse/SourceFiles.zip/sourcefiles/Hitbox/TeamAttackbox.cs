﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TeamAttackbox : Attackbox {
	
	/// <summary>
	/// Returns if attackbox can hit target the specified target.
	/// </summary>
	/// <param name="target">Target.</param>
	protected override bool can_hit_target(CharacterStatus target) {
		
		//Check if player is on team
		if (target.team_number != attack.team_number) {
			
			return false;
		}
		
		//Check if already hit
		foreach (CharacterStatus hit_character in attack.affected_characters) {
			
			if (hit_character == target) {
				
				return false;
			}
		}
		return true;
	}
}
