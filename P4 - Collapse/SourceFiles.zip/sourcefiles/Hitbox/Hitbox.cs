﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Hitbox : MonoBehaviour {
	
	public Hitbox() {
	
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public virtual void OnTriggerEnter(Collider in_collider) {
					
		Hitbox temp = in_collider.gameObject.GetComponent<Hitbox>();
		
		//check if collision is with a hitbox
		if (temp != null) {
		
			//check if collision is not with player hitboxes
			if (transform.root != in_collider.transform.root) {			
			
				//print("hitbox collided with " + in_collider.name);
				this.Effect(temp);
			}
		}
		return;
	}
	
	//Effect the certain hitbox will perform
	public virtual void Effect(Hitbox hitbox) {
		
		//Do nothing
	}

	public virtual GameObject get_owner() {
		
		return transform.root.gameObject;
	}
}
