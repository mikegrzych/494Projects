﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Hurtbox : Hitbox {
	
	public CharacterStatus character_status {
	
		get {
		
			return transform.root.GetComponent<CharacterStatus>();
		}
	} 
		
	// Use this for initialization
	void Start () {
	
		//character_status = transform.root.GetComponent<CharacterStatus>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	//Effect the certain hitbox will perform
	public virtual void Effect(Hitbox hitbox) {
		
		//Do nothing on effects
	}
}
