﻿using UnityEngine;
using System.Collections;

public class restrict_to_xy_plane : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
		Vector3 pos = transform.position;
		pos.z = -3;
		transform.position = pos;
	}
}
