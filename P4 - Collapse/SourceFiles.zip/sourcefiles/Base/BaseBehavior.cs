﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BaseBehavior : MonoBehaviour {

	List<CharacterStatus> PlayersOnTeam;
	public int team_number;
	public float team_points;

	// Use this for initialization
	void Awake () {
		PlayersOnTeam = new List<CharacterStatus>();
		team_points = 100;
		this.tag = "Base";
	}

	// Update is called once per frame
	void Update () {
		
	}

	public void AddPlayerToTeam(CharacterStatus cs) {
		PlayersOnTeam.Add(cs);
		cs.SetRespawnPoint(transform.position);
		//cs.SetTeamNumber(team_number);
	}

	public static BaseBehavior FindBase(TeamId team) {
		int num = (int) team;
		GameObject[] bases = GameObject.FindGameObjectsWithTag("Base");
		foreach(GameObject go in bases) {
			BaseBehavior b = go.GetComponent<BaseBehavior>();
			if(b.team_number == num) {
				//print("found a base!");
				return b;
			}
		}
		print("didn't find a base. this shouldn't happen :(");
		return null;
	}
}
