﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LotsaSpawn : MonoBehaviour {
	public GameObject 		myPrefab;
	public float			radius = 10f;
	public List<GameObject>	spawnedObjects;
	float time = 0f;
	
	// Use this for initialization
	void Start () {
		spawnedObjects = new List<GameObject>();
	}
	
	// Update is called once per frame
	void Update () {
		time += Time.deltaTime;
		if (time > 0.5f) {
			GameObject go = Instantiate(myPrefab) as GameObject;
			go.transform.position = transform.position + Random.insideUnitSphere*radius;
			//spawnedObjects.Add(go);
		}
	}
}
