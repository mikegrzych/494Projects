﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LobbyPlayer {
	private NetworkPlayer _networkPlayer;
	private string _name;
	private TeamId _team;
	private CharacterId _character;

	public LobbyPlayer(NetworkPlayer np, string name = null, TeamId team = TeamId.NEUTRAL, CharacterId c = CharacterId.ICE_GOLEM) {
		this._networkPlayer = np;
		this._name = name;
		this._team = team;
		this._character = c;
	}

	public TeamId Team {
		get { return _team; }  
		set { _team = value; }
	}

	public int TeamNumber {
		get { return (int) _team; }
	}

	public string Name {
		get { return _name; }
		set { _name = value; }
	}

	public CharacterId Character {
		get { return _character; }
		set { _character = value; }
	}

	public int CharacterNumber {
		get { return (int) _character; }
	}

	public NetworkPlayer networkPlayer {
		get { return _networkPlayer; }
	}

	public bool CanBeDisplayed() {
		return Name != null;
	}
}

public class GlobalPlayer : MonoBehaviour {
	public string Name = "Jeremy Gibson";
	public TeamId Team = TeamId.RED;
	public int TeamInt {
		get { return (int) Team; }
	}
	public CharacterId Character = CharacterId.ICE_GOLEM;
	public int CharacterNumber {
		get { return (int) Character; }
	}

	public void Awake() {
		DontDestroyOnLoad(this);
	}
}
