﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Net;

public class GameCreateInfo {
	public string game_name = "Jeremy Gibson's Game";
	public string game_description = NetUtils.CLOSED_GAME;
};

public class JoinController : MonoBehaviour {

	// Set by Unity Editor
	public GUISkin MenuSkin;
	public GUISkin SettingsSkin;
	public ScreenInfo screenInfo;

	public MenuController Menu;
	public PregameLobbyController PregameLobby;
	
	private HostData[] hosts;

	private GameCreateInfo hostGameInfo;

	public Texture[] tutorials = new Texture[5];
	private int tutorials_index = 0;

	void Awake () {
		// Set up what network games we're looking for
		RequestHosts();
	}

	// Use this for initialization
	void Start () {
		hostGameInfo = new GameCreateInfo();
	}
	
	// Update is called once per frame
	void Update () {

	}

	void OnServerInitialized() {
		GameObject GUIGameObject = GameObject.Find("GUI");
		if (GUIGameObject != null) {
			GUIGameObject.SendMessage("OnHostGame", hostGameInfo);
		}
	}

	void OnMasterServerEvent(MasterServerEvent msEvent) {
		if (msEvent == MasterServerEvent.HostListReceived)
			hosts = MasterServer.PollHostList();
	}

	public void StartHost(string gameName) {
		Network.InitializeServer(35, 20709, !Network.HavePublicAddress());
		MasterServer.RegisterHost(NetUtils.NET_GAME_TYPE, gameName, NetUtils.OPEN_GAME);
	}
	
	public void RequestHosts() {
		MasterServer.RequestHostList(NetUtils.NET_GAME_TYPE);
	}
	
	public void ConnectToHost(HostData host) {
		Network.Connect(host);
	}

	// Set up the GUI
	void OnGUI() {
		GUI.skin = MenuSkin;
		MenuState current = Menu.History.Peek();
		// Setting a GUIStyle here would be good
		GUILayout.BeginArea(new Rect(screenInfo.HorizontalGrid[2], 0, 6.0f * screenInfo.TenthHorizontal, screenInfo.Height));
		GUILayout.BeginVertical();
		GUILayout.Box("Collapse");

		switch (current) {
		case MenuState.MAIN:
			drawMainMenu();
			break;
		case MenuState.JOIN:
			drawJoinMenu();
			break;
		case MenuState.HOST:
			drawHostMenu();
			break;
		case MenuState.TUTORIAL:
			drawTutorial();
			break;
		default:
			break;
		}
		GUILayout.EndVertical();
		GUILayout.EndArea();

	}

	void drawMainMenu ()
	{
		GUILayout.BeginHorizontal();
		if (GUILayout.Button ("Join Game")) {
				RequestHosts ();
				Menu.History.Push (MenuState.JOIN);
		}
		if (GUILayout.Button ("Host Game")) {
			print("Host game Clicked");
			Menu.History.Push(MenuState.HOST);
		}
		if (GUILayout.Button("Help")) {
			Menu.History.Push(MenuState.TUTORIAL);
		}
		GUILayout.EndHorizontal();
	}
	
	void drawJoinMenu ()
	{
		GUILayout.BeginHorizontal();
		GUI.skin = SettingsSkin;
		GUILayout.Label("Your Name:");
		Menu.Me.Name = GUILayout.TextField(Menu.Me.Name, 32);
		GUI.skin = MenuSkin;
		GUILayout.EndHorizontal();
		int hostCount = 0;
		foreach (HostData host in hosts) {
			if (host.comment == NetUtils.OPEN_GAME) {
				++hostCount;
			}
		}
		GUILayout.Label("Game List (" + hostCount + " Games Found)");
		GUILayout.BeginVertical();
		if (hosts != null) {
			foreach (HostData host in hosts) {
				if (host.comment != NetUtils.OPEN_GAME) {
					continue;
				}
				if (GUILayout.Button(host.gameName)) {
						print("Selected " + host.gameName);
						ConnectToHost(host);
					}
				}
			}
		GUILayout.EndVertical();
		if (GUILayout.Button("Refresh")) {
			RequestHosts();
		}
		if (GUILayout.Button("Back")) {
			Menu.History.Pop();
		}
	}
	
	void joinGame(HostData host) {
		if (!Network.isClient && !Network.isServer) {
			Network.Connect(host);
		}
	}

	void drawHostMenu()
	{
		GUI.skin = SettingsSkin;
		GUILayout.BeginHorizontal();
		GUILayout.Label("Your Name:");
		Menu.Me.Name = GUILayout.TextField(Menu.Me.Name, 32);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		GUILayout.Label("Game Name:");
		hostGameInfo.game_name = GUILayout.TextField(hostGameInfo.game_name, 32);
		GUILayout.EndHorizontal();
		GUI.skin = MenuSkin;
		if (GUILayout.Button("Create")) {
			StartHost(hostGameInfo.game_name);
			//menuHistory.Push(MenuState.LOBBY);
		}
		if (GUILayout.Button("Back")) {
			Menu.History.Pop();
		}
	}

	void drawTutorial() {
		GUILayout.BeginVertical();
		GUILayout.Label(tutorials[tutorials_index], GUILayout.Height(430));
		if(GUILayout.Button ("Next")) {
			tutorials_index++;
			if(tutorials_index >= 5) {
				tutorials_index = 0;
				Menu.History.Pop();
			}
		}
		if (GUILayout.Button("Back")) {
			tutorials_index--;
			if(tutorials_index <= 0) {
				tutorials_index = 0;
				Menu.History.Pop();
			}
		}
		GUILayout.EndVertical();
	}
	
}
