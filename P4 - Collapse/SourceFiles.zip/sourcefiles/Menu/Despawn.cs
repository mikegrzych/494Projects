﻿using UnityEngine;
using System.Collections;

public class Despawn : MonoBehaviour {
	// Use this for initialization
	void Start () {
		Destroy(gameObject,4f);
	}
	
	// Update is called once per frame
	void Update () {

	}
}
