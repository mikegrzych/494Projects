﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PregameLobbyController : MonoBehaviour {

	public MenuController Menu;
	public GUISkin MenuSkin;
	public GUISkin PlayerInfoSkin;
	public ScreenInfo screenInfo;

	private Dictionary<NetworkPlayer, LobbyPlayer> _players = new Dictionary<NetworkPlayer, LobbyPlayer>();
	private string _GameName = "";

	public string GameName {
		get { return Network.isServer ? _GameName : ""; }
		set { _GameName = Network.isServer ? value : ""; }
	}

	private int characterGridSelection = 0;
	private int teamGridSelection = 0;

	void OnPlayerDisconnected(NetworkPlayer player) {
		networkView.RPC("RPC_RemovePlayer", RPCMode.All, player);
	}

	void OnDisconnectedFromServer(NetworkDisconnection e) {
		_players.Clear();
	}

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnGUI() {
		if (Menu.History.Peek() == MenuState.LOBBY) {
			DrawLobby();
		}
	}

	void DrawLobby() {
		GUI.skin = PlayerInfoSkin;
		Rect areaRect = new Rect(screenInfo.HorizontalGrid[1], screenInfo.VerticalGrid[3], 8.0f * screenInfo.TenthHorizontal, 8.0f * screenInfo.Height);
		GUILayout.BeginArea(areaRect);
		GUILayout.BeginVertical();
		DrawCharacterSelect();
		DrawTeamSelect();
		GUILayout.BeginHorizontal();
		GUILayout.Label("Player");
		GUILayout.Label("Character");
		GUILayout.Label("Team");
		GUILayout.EndHorizontal();
		foreach (KeyValuePair<NetworkPlayer, LobbyPlayer> kvp in _players) {
			LobbyPlayer lp = kvp.Value;
			if (lp.CanBeDisplayed()) {
				DrawPlayerInfo(lp);
			}
		}
		if (Network.isServer) {
			if (GUILayout.Button("Launch Game")) {
				LaunchGame();
			}
		}
		if (GUILayout.Button("Leave")) {
			LeaveGame();
		}
		GUILayout.EndVertical();
		GUILayout.EndArea();
	}

	void DrawTeamSelect() {
		int selected = GUILayout.SelectionGrid(teamGridSelection, TeamUtils.TEAM_NAMES, 2);
		if (selected != teamGridSelection) {
			teamGridSelection = selected;
			Menu.Me.Team = TeamUtils.GetTeam(selected);
			NotifyPlayerChange();
		}
	}

	void DrawCharacterSelect() {
		int selected = GUILayout.SelectionGrid(characterGridSelection, CharacterUtils.CHARACTER_NAMES, 4);
		if (selected != characterGridSelection) {
			characterGridSelection = selected;
			Menu.Me.Character = CharacterUtils.GetCharacter(characterGridSelection);
			NotifyPlayerChange();
		}
	}

	void DrawPlayerInfo(LobbyPlayer lp) {
		GUILayout.BeginHorizontal();
		GUILayout.Label(lp.Name);
		GUILayout.Label(lp.Character.ToString());
		GUILayout.Label(TeamUtils.GetName(lp.Team));
		GUILayout.EndHorizontal();
	}

	void LeaveGame() {
		_players.Clear();
		Network.Disconnect(1000);
	}

	void LaunchGame() {
		if (Network.isServer) {
			Network.maxConnections = 0;
			MasterServer.RegisterHost(NetUtils.NET_GAME_TYPE, GameName, NetUtils.CLOSED_GAME);
			foreach (KeyValuePair<NetworkPlayer, LobbyPlayer> kvp in _players) {
				LobbyPlayer lp = kvp.Value;
				networkView.RPC("RPC_SetPlayerData", RPCMode.OthersBuffered, lp.networkPlayer, lp.Name, lp.TeamNumber, lp.CharacterNumber);
			}
			networkView.RPC("RPC_LaunchGame", RPCMode.AllBuffered);
		}
	}

	void OnPlayerConnected(NetworkPlayer player) {
		//_players.Add(player, new LobbyPlayer(player));
	}

	void OnServerInitialized() {
		Menu.Me.Character = CharacterUtils.GetCharacter(characterGridSelection);
		Menu.Me.Team = TeamUtils.GetTeam(teamGridSelection);
		_players.Clear();
		_players.Add(Network.player, new LobbyPlayer(Network.player, Menu.Me.Name, Menu.Me.Team));
	}

	void OnHostGame(GameCreateInfo hostGameInfo) {
		GameName = hostGameInfo.game_name;
	}

	void OnConnectedToServer() {
		Menu.Me.Character = CharacterUtils.GetCharacter(characterGridSelection);
		Menu.Me.Team = TeamUtils.GetTeam(teamGridSelection);
		_players.Clear();
		networkView.RPC("RPC_RequestPlayerDataFromServer", RPCMode.Server, Network.player);
		networkView.RPC("RPC_RequestSetPlayerData", RPCMode.Server, Network.player, Menu.Me.Name, Menu.Me.TeamInt, Menu.Me.CharacterNumber);
	}
		
	void NotifyPlayerChange() {
		if (Network.isServer) {
			RPC_RequestSetPlayerData(Network.player, Menu.Me.Name, Menu.Me.TeamInt, Menu.Me.CharacterNumber);
		} else {
			networkView.RPC("RPC_RequestSetPlayerData", RPCMode.Server, Network.player, Menu.Me.Name, Menu.Me.TeamInt, Menu.Me.CharacterNumber);
		}
	}
	
	void SetPlayerData(NetworkPlayer player, string name, int teamNumber, int character) {
		TeamId team = TeamUtils.GetTeam(teamNumber);
		CharacterId c = CharacterUtils.GetCharacter(character);
		LobbyPlayer lp = new LobbyPlayer(player, name, team, c);
		print(lp);
		_players[player] = lp;
	}

	[RPC]
	void RPC_RequestPlayerDataFromServer(NetworkPlayer requester) {
		if (!Network.isServer) {
			return;
		}
		foreach(KeyValuePair<NetworkPlayer, LobbyPlayer> kv in _players) {
			if (kv.Key != requester) {
				LobbyPlayer lp = kv.Value;
				networkView.RPC("RPC_SetPlayerData", requester, lp.networkPlayer, lp.Name, lp.TeamNumber, lp.CharacterNumber);
			}
		}
	}

	[RPC]
	void RPC_RequestSetPlayerData(NetworkPlayer player, string name, int teamNumber, int character) {
		print("yolo");
		if (!Network.isServer) {
			return;
		}
		print("hello");
		SetPlayerData(player, name, teamNumber, character);
		networkView.RPC("RPC_SetPlayerData", RPCMode.Others, player, name, teamNumber, character);
	}

	// Says that player has the given name, teamNumber, and character
	[RPC]
	void RPC_SetPlayerData(NetworkPlayer player, string name, int teamNumber, int character) {
		SetPlayerData(player, name, teamNumber, character);
	}

	[RPC]
	void RPC_RemovePlayer(NetworkPlayer player) {
		_players.Remove(player);
	}

	[RPC]
	void RPC_LaunchGame() {
		//_players.Clear();
		Application.LoadLevel("basic_level");
	}


}
