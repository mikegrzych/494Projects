﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent (typeof(NetworkView))]
public class PointController : MonoBehaviour {

	public int PointsPerUpdate = 1;
	public int InitialPoints = 0;
	public int PointsToWin = 100;
	public GUISkin MenuSkin;
	public GUISkin HUDSkin;
	
	public Texture2D PointBackgroundTexture;
	public Texture2D DividerTexture;


	private Dictionary<TeamId, int> _points = new Dictionary<TeamId, int>();

	public int RedTeamPoints {
		get { return _points[TeamId.RED]; }
		set { _points[TeamId.RED] = value; }
	}
	public int BlueTeamPoints {
		get { return _points[TeamId.BLUE]; }
		set { _points[TeamId.BLUE] = value; }
	}

	public bool gameOver;
	public string winner;

	public float UpdateDelta = 1.0f;

	private GUIStyle gameOverStyle;
	private float endTime;

	private float lastScoreUpdateTime;


	private List<ControlPointStatus> cps = new List<ControlPointStatus>();

	// Use this for initialization
	void Start () {
		gameOverStyle = new GUIStyle();
		gameOverStyle.alignment = TextAnchor.MiddleCenter;
		gameOverStyle.fontSize = 62;
		foreach (GameObject go in GameObject.FindGameObjectsWithTag("ControlZone")) {
			cps.Add(go.GetComponent<ControlPointStatus>());
		}
		lastScoreUpdateTime = Time.time;
		RedTeamPoints = BlueTeamPoints = InitialPoints;
	}

	void Update() {
		if (Network.isServer) {
			if (gameOver) {
				if (Time.time > endTime + 10.0f) {
					networkView.RPC ("EndGame", RPCMode.Others);
					if (Network.connections.Length <= 1) {
						EndGame();
					}
				}
			}
			if (Time.time > lastScoreUpdateTime + UpdateDelta) {
				if (!gameOver) {
					foreach (ControlPointStatus cs in cps) {
						if (cs.ControlledBy != TeamId.NEUTRAL) {
							_points[cs.ControlledBy] += PointsPerUpdate;
						}
					}
					foreach (KeyValuePair<TeamId, int> kvp in _points) {
						if (kvp.Value > PointsToWin) {
							_points[kvp.Key] = PointsToWin;
						}
					}
				}
				lastScoreUpdateTime = Time.time;
				networkView.RPC("SendPoints", RPCMode.Others, RedTeamPoints, BlueTeamPoints);
			}
		}
	}


	// Update is called once per frame
	void FixedUpdate () {

		if (gameOver) {
			return;
		}
		if (RedTeamPoints >= PointsToWin) {
			gameOver = true;
			winner = "Red Team Wins!";
		} else if (BlueTeamPoints >= PointsToWin) {
			gameOver = true;
			winner = "Blue Team Wins!";
		}

		if (gameOver) {
			endTime = Time.time;
		}
	}

	[RPC]
	void SendPoints(int redTeam, int blueTeam) {
		RedTeamPoints = redTeam;
		BlueTeamPoints = blueTeam;
	}

	[RPC]
	void EndGame() {
		if (Network.isClient) {
			Network.CloseConnection(Network.connections[0], true);
		} else if (Network.isServer) {
			Network.Disconnect();
		}
		//DestroyImmediate(GameObject.Find("Me"));
		Application.LoadLevel("menu_david");
	}

	Rect GetTeamRectange(TeamId team) {
		float left = Screen.width * 0.2f;
		float top = Screen.height * 0.9f;
		float width = Screen.width * 0.6f;
		float height = Screen.height * 0.05f;
		if (team == TeamId.BLUE) {
			width *= 0.5f;
			left += width;
			width *= (float) _points[TeamId.BLUE] / (float) PointsToWin;

		} else if (team == TeamId.RED) {
			width *= 0.5f;
			float offset = width;
			width *= (float) _points[TeamId.RED] / (float) PointsToWin;
			offset -= width;
			left += offset;
		}
		return new Rect(left, top, width, height);
	}


	void OnGUI() {
		GUI.skin = MenuSkin;
		string redTeamScore = RedTeamPoints.ToString();
		string blueTeamScore = BlueTeamPoints.ToString();
		Rect redScoreLoc = new Rect(Screen.width * 0.05f, Screen.height * 0.9f, Screen.width * 0.1f, Screen.height * 0.05f);
		//GUIStyle style = new GUIStyle();
		//style.alignment = TextAnchor.LowerRight;
		Rect blueScoreLoc = new Rect(Screen.width * 0.85f, Screen.height * 0.9f, Screen.width * 0.1f, Screen.height * 0.05f);
		GUI.color = Color.red;
		GUI.Label(redScoreLoc, redTeamScore, "pointlabelred");
		GUI.color = Color.blue;
		GUI.Label(blueScoreLoc, blueTeamScore, "pointlabelblue");

		Rect full = GetTeamRectange(TeamId.NEUTRAL);
		GUI.color = ControlPointStatus.BACKGROUND_COLOR;
		GUI.DrawTexture(full, PointBackgroundTexture);
		Rect red = GetTeamRectange(TeamId.RED);
		GUI.color = ControlPointStatus.RED_TEAM_COLOR;
		GUI.DrawTexture(red, PointBackgroundTexture);
		Rect blue = GetTeamRectange(TeamId.BLUE);
		GUI.color = ControlPointStatus.BLUE_TEAM_COLOR;
		GUI.DrawTexture(blue, PointBackgroundTexture);
		GUI.color = Color.black;
		Rect black = new Rect(Screen.width * 0.5f - Screen.height * 0.025f, Screen.height * 0.9f, Screen.height * 0.05f, Screen.height * 0.05f);
		GUI.DrawTexture(black, DividerTexture);
		GUI.color = Color.white;


		if (gameOver) {
			float StartX = 0;
			float StartY = Screen.height * 0.5f - 100;
			GUI.skin = MenuSkin;
			GUI.Box(new Rect(StartX, StartY, Screen.width, Screen.height * 0.3f), winner);
		}


	}
	
}
