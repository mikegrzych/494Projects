﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MenuController : MonoBehaviour {

	public Stack<MenuState> History = new Stack<MenuState>();

	public GlobalPlayer Me;

	void Awake() {
		History.Push(MenuState.MAIN);
	}

	void OnConnectedToServer() {
		History.Push(MenuState.LOBBY);
	}

	void OnDisconnectedFromServer(NetworkDisconnection info) {
		History.Clear();
		History.Push(MenuState.MAIN);
	}

	void OnServerInitialized() {
		History.Push(MenuState.LOBBY);
	}

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
