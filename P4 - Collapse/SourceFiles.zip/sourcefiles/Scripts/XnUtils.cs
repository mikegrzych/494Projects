using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Array = System.Array;

public class XnUtils : MonoBehaviour {
	static private XnUtils	_S;
	
	static private bool		SINGLETON_INITED = false;
	static public bool		DEBUG_DEFAULT = true;
	
	static public string	_LOG_HEADER = "";
	static public string	LOG = "";
	static public List<string>	LOGS;
	static public List<string>	LOG_HEADERS;
	
	static public bool		TRACE_LOG = false;
	static public bool		CLEAR_LOG_ON_PRINT = true;
// TODO: Look this number up so that I'm correct!!!
	static public int		MAX_STRING_LENGTH = 999999;
	static public KeyCode	PRINT_KEY_DEFAULT = KeyCode.BackQuote;
	static public bool		SPLIT_VECTOR_COMPONENTS_ON_LOG = true;
	
	public bool				debug = DEBUG_DEFAULT;
	public KeyCode			printKey = KeyCode.BackQuote;
	public bool				printThisFrame = false;
	
	
// INSTANCE FUNCTIONS - An instance is created by any function which runs in the background to do things like print the log
	public void Update() {
		printThisFrame = Input.GetKeyDown(printKey);
	}
	
	
	public void LateUpdate() {
		if (printThisFrame) {
			PrintLog();
			printThisFrame = false;
		}
		// NOTE: This prevents the LOG from exceeding the max length in memory
		if (LOG.Length >= MAX_STRING_LENGTH) {
			PrintLog();
			LOG = "";
		}
	}
	
// STATIC FUNCTIONS
	
// ====================== XnUtils Singleton Functions ======================
	static public XnUtils S {
		get {
			if (_S != null) return(_S);
			MakeUtilsGameObject();
			return(_S);
		}
		set {
			_S = value;
		}
	}
	
	// Generate a singleton of XnUtils to handle keyboard input and such
	static void MakeUtilsGameObject() {
		if (SINGLETON_INITED) return;
		SINGLETON_INITED = true;
		GameObject go = new GameObject("XnUtils");
		go.AddComponent("XnUtils");
		_S = go.GetComponent<XnUtils>();
		if (LOGS == null) LOGS = new List<string>();
		if (LOG_HEADERS == null) LOG_HEADERS = new List<string>();
	}
	
	
	
	
	
	
// ====================== Other Functions ======================
	
	
	// BreakPoint can be called from anywhere to cause a breakpoint
	// XnUtils.BreakPoint();
	static public void BreakPoint() {
		
		
		int i = 0;//Debug.Log("BreakPoint!!!");
		i++;  // This stops the stupid "variable is assigned but never used" warning
		
		
	}
	
	
// ====================== Camera Functions ======================
	
	static public Rect GetBoundsAt0(string mode="xy") {
		Rect r = new Rect();
		Camera cam = Camera.main;
		if (mode == "xy") {
			Vector3 bl = cam.ScreenToWorldPoint ( new Vector3 (0,0,-cam.transform.position.z) );
			Vector3 tr = cam.ScreenToWorldPoint ( new Vector3 (cam.pixelWidth,cam.pixelHeight,-cam.transform.position.z) );
			r.xMin = bl.x;
			r.yMin = bl.y;
			r.xMax = tr.x;
			r.yMax = tr.y;
		} else if (mode == "xz") {
			Vector3 bl = cam.ScreenToWorldPoint ( new Vector3 (0,0,-cam.transform.position.y) );
			Vector3 tr = cam.ScreenToWorldPoint ( new Vector3 (cam.pixelWidth,cam.pixelHeight,-cam.transform.position.y) );
			r.xMin = bl.x;
			r.yMin = bl.z;
			r.xMax = tr.x;
			r.yMax = tr.z;
		}
		return(r);
	}
	
	static public Rect CameraBounds() {
		return( GetBoundsAt0() );
	}
	
	static public Rect cameraBounds {
		get {
			return( CameraBounds() );
		}
	}
	
	static public Rect CameraBoundsXZ() {
		return( GetBoundsAt0("xz") );
	}
	
	static public Rect cameraBoundsXZ {
		get {
			return( GetBoundsAt0("xz") );
		}
	}
	
	// Picks a random XY0 point which is guaranteed to be at least 10% of the dist from the center to the corner of the screen off screen
	static public Vector3 randomPointOffScreen {
		get {
			return( RandomPointOffScreen( 10f ) );
		}
	}
	// Picks a random XY0 point which is guaranteed to be at least percentOffScreen% of the dist from the center to the corner of the screen off screen
	static public Vector3 RandomPointOffScreen(float percentOffScreen) {
		Rect bounds = cameraBounds;
		float distToCorner = Mathf.Sqrt( bounds.width*bounds.width + bounds.height*bounds.height ) / 2f;
		float dist = distToCorner * (1f + (percentOffScreen*0.01f));
		Vector3 vec = Random.onUnitSphere;
		vec.z = 0;
		vec.Normalize();
		vec *= dist;
		return(vec);
	}
	
	static public Vector3 randomPointOnScreen {
		get {
			return( RandomPointOnScreen( 10f ) );
		}
	}
	
	static public Vector3 RandomPointOnScreen( float percentOnScreenBorder ) {
		Rect bounds = cameraBounds;
		Vector3 vec = Vector3.zero;
		percentOnScreenBorder = 1f - ((percentOnScreenBorder / 2f)*0.01f);
		float rX = Random.value;
		float rY = Random.value;
		vec.x = (1-rX)*(bounds.xMin*percentOnScreenBorder) + rX*(bounds.xMax*percentOnScreenBorder);
		vec.y = (1-rY)*(bounds.yMin*percentOnScreenBorder) + rY*(bounds.yMax*percentOnScreenBorder);
		return(vec);
	}
	
	// XnUtils.mouseLoc
	static public Vector3 mouseLoc {
		get {
			return( GetMouseLoc() );
		}
	}
	static public Vector3 GetMouseLoc() {
		Vector3 pos = Input.mousePosition;
		Vector3 loc = Camera.main.ScreenToWorldPoint( new Vector3 (pos.x, pos.y, -Camera.main.transform.position.z) );
		return(loc);
	}
	
	
	static Quaternion	billboardOldRot, billboardRot;
	static float		billboardDot, billboardU;
	static public void Billboard( GameObject go, float maxRotation = 9000 ) {
		Billboard( go, Vector3.up, maxRotation );
	}
	static public void Billboard( GameObject go, Vector3 up, float maxRotation = 9000 ) {
		billboardOldRot = go.transform.rotation;
		go.transform.LookAt( Camera.main.transform.position, up );
		
		if (maxRotation != 9000) {
			billboardDot = Quaternion.Dot( billboardOldRot, go.transform.rotation );
			billboardU = (maxRotation*Time.deltaTime) / billboardDot;
			if (billboardU < 1) {
				billboardRot = Quaternion.Lerp( billboardOldRot, go.transform.rotation, billboardU );
				go.transform.rotation = billboardRot;
			}
		}
		
	}
	
	
	
// ====================== Array/List Functions ======================
	/*
	static public int IndexOf( T[] eArray, T element ) {
		for (int i=0; i<eArray.Length; i++) {
			if ( eArray[i] == element ) {
				return( i );
			}
		}
		return( -1 );
	}
	*/
	static public int IndexOf( object[] eArray, object element ) {
		for (int i=0; i<eArray.Length; i++) {
			if ( eArray[i] == element ) {
				return( i );
			}
		}
		return( -1 );
	}
	
	/*
	static public string ArrayToString<T>( IList<T> coll ) {
		List<string> ss = new List<string>();
		foreach( T item in coll ) {
			ss.Add( item.ToString() );
		}
		string s = string.Join( ",", ss.ToArray() );
		return( s );
	}
	// This version allows for something that's not a collection to be passed in
	static public string ToString<T>( T item ) {
		if (item is IList) {
			return( ArrayToString(item as IList) );
		}
		return( item.ToString() );
	}
	*/
	/* Handling a Generic list or array example
class Program
{
    static void Main()
    {
        int[] arr = { 0, 1, 2, 3, 4 };
        List<int> list = new List<int>();

        for (int x = 5; x < 10; x++)
        {
            list.Add(x);
        }

        ProcessItems<int>(arr);
        ProcessItems<int>(list);
    }

    static void ProcessItems<T>(IList<T> coll)
    {
        // IsReadOnly returns True for the array and False for the List.
        System.Console.WriteLine
            ("IsReadOnly returns {0} for this collection.",
            coll.IsReadOnly);

        // The following statement causes a run-time exception for the  
        // array, but not for the List. 
        //coll.RemoveAt(4); 

        foreach (T item in coll)
        {
            System.Console.Write(item.ToString() + " ");
        }
        System.Console.WriteLine();
    }
}
	*/
	
	

	
	
// ====================== Color Functions ======================
	
	static public Color ColorMixAdditive( Color c0, Color c1 ) {
		Color c = c0;
		if (c1.r > c.r) c.r = c1.r;
		if (c1.g > c.g) c.g = c1.g;
		if (c1.b > c.b) c.b = c1.b;
		return( c );
	}
	
	
	
	
	
// ====================== Randomization Functions ======================
	
	// Generates a random int which is from 0 (inclusive) to limit (exclusive)
	// So XnUtils.RandInt(5) => 0, 1, 2, 3, or 4
	static public int RandInt( int limit ) {
		float rF = Random.value * (float) limit;
		int rI = Mathf.FloorToInt( rF );
		if (rI == limit) rI--;
		return( rI );
	}
	
	static public float GetRandInRange( float min, float max ) {
		if (min > max) {
			float f = min;
			min = max;
			max = f;
		}
		return( (max - min) * Random.value + min );
	}
	
	static public Vector3 GetRandInRect( Rect r ) {
		Vector3 v = Vector3.zero;
		v.x = GetRandInRange( r.xMin, r.xMax );
		v.y = GetRandInRange( r.yMin, r.yMax );
		return( v );
	}
	static public Vector2 GetRandInRectV2( Rect r ) {
		Vector3 v = GetRandInRect( r );
		Vector2 v2 = new Vector2( v.x, v.y );
		return( v2 );
	}
	
	// XnUtils.GetNumWithVariance(100, 20) => Numbers from 80 to 120
	static public float GetNumWithVariance( float num, float variance ) {
		return( num-variance + (Random.value * 2 * variance) );
	}
	
	
	static public List<T> RandomSort<T>(List<T> sequence)
	{
	    T[] retArray = sequence.ToArray();
	
	
	    for (int i = 0; i < retArray.Length - 1; i += 1)
	    {
	        int swapIndex = XnUtils.RandInt( retArray.Length-i ) + i;
	        T temp = retArray[i];
	        retArray[i] = retArray[swapIndex];
	        retArray[swapIndex] = temp;
	    }
	
	    return( new List<T>( retArray ) );
	}
	
	
// ====================== String and Logging Functions ======================
	static public string Str(object o) {
		string s = "";
		
		//print( o.GetType().ToString() );
		
		if ( o.GetType().IsArray ) {
			s = KnownArrayToTabbedString( o );
		//} else if ( o is List ) { //.GetType().ToString() == "List" ) {
			//s = KnownArrayToTabbedString( (o as IList).ToArray() );
		} else {
			s = o.ToString();
			
			if (o is Vector3 && SPLIT_VECTOR_COMPONENTS_ON_LOG) {
				Vector3 v3 = (Vector3) o;
				s = v3.x+"\t"+v3.y+"\t"+v3.z+"\t"; // Inserts a double-tab between Vector3s
			}
			if (o is Vector2) {
				Vector2 v2 = (Vector2) o;
				s = "( "+v2.x+", "+v2.y+" )";
			}
				
			
		}
		
		/*
		//Debug.Log(typeof(o));
		//if ( typeof(o) == typeof(object[]) ) {
		if ( typeof(o) == 
		
		if ( o is Vector3[] ) {
			s = Vector3ArrayToTabbedString(o as Vector3[]);
		} else if ( o is int[] ) {
			s = IntArrayToTabbedString(o as int[]);
		} else if ( o is Vector2[] ) {
			s = Vector2ArrayToTabbedString(o as Vector2[]);
		} else {
			s = o.ToString();
		}
		*/
		
		return(s);
	}
	
	static public string KnownArrayToTabbedString( object o ) {
		string str = "";
		int ndx = 0;
		foreach (object obj in (Array)o) {
			if (ndx == 0) {
				str += Str( obj );
			} else {
				str += "\t" + Str( obj );
			}
			ndx++;
		}
		/*
		Array ss = (Array) o;
		string str = Str(ss[0]);
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		*/
		return(str);
	}
	/*
	static public string KnownListToTabbedString( List<T> l ) {
		string str = "";
		int ndx = 0;
		foreach (T obj in l) {
			if (ndx == 0) {
				str += Str( obj );
			} else {
				str += "\t" + Str( obj );
			}
			ndx++;
		}
		/*
		Array ss = (Array) o;
		string str = Str(ss[0]);
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		*
		return(str);
	}
	*/
	
	/*
	static public string IntArrayToTabbedString(int[] ss) {
		if (ss.Length == 0) return("");
		//string str = (string) ss[0];
		string str = Str(ss[0]);//ss[0].ToString();
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		return(str);
	}
	
	
	static public string Vector2ArrayToTabbedString(Vector2[] ss) {
		if (ss.Length == 0) return("");
		//string str = (string) ss[0];
		string str = Str(ss[0]);//ss[0].ToString();
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		return(str);
	}
	
	
	static public string Vector3ArrayToTabbedString(Vector3[] ss) {
		if (ss.Length == 0) return("");
		//string str = (string) ss[0];
		string str = Str(ss[0]);//ss[0].ToString();
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		return(str);
	}
	
	static public string ArrayListToTabbedString(ArrayList ss) {
		if (ss.Count == 0) return("");
		//string str = (string) ss[0];
		string str = Str(ss[0]);//ss[0].ToString();
		for (int i=1; i<ss.Count; i++) {
			str += "\t"+Str(ss[i]);
		}
		return(str);
	}
	*/
		
	
	
	static public string ArrayToTabbedString(params object[] ss) {
		if (ss.Length == 0) return("");
		//string str = (string) ss[0];
		string str = Str(ss[0]);//ss[0].ToString();
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+Str(ss[i]);
		}
		return(str);
	}
	
	static public void Log(params object[] ss) {
		Log(0, ss);
	}
	static public void Log(int ndx, params object[] ss) {
		MakeUtilsGameObject();
		
		while (LOG_HEADERS.Count < ndx+1) {
			LOG_HEADERS.Add("");
		}
		
		string str = ArrayToTabbedString(ss);
		str += "\r";
		while (ndx >= LOGS.Count) {
			LOGS.Add("");
		}
		LOGS[ndx] += str;
		if (TRACE_LOG) Debug.Log(str);
	}
	
	static public void PrintLog() {
		PrintLog(0);
	}
	static public void PrintLog(int ndx) {
		if (LOGS == null || LOGS.Count == 0) return;
		MakeUtilsGameObject();
		string str = "=====LOG "+ndx+"=====\tFrame\ttime\tfixedTime\n";
		str += ArrayToTabbedString("", Time.frameCount, Time.time, Time.fixedTime)+"\n\n";
		//if (LOG_HEADER.Length>0) str += LOG_HEADER+"\n";
		if (LOG_HEADERS[ndx].Length>0) str += LOG_HEADERS[ndx]+"\n";
		Debug.Log(str+LOGS[ndx]);
		LOGS[ndx] += "\n\n\n\n\n";
		if (CLEAR_LOG_ON_PRINT) {
			LOGS[ndx] = "";
			LOG_HEADER = "";
		}
	}
	
	static public void ClearLog() {
		ClearLog(0);
	}
	static public void ClearLog(int ndx) {
		if (LOGS == null) LOGS = new List<string>();
		if (LOGS.Count > ndx) {
			LOGS[ndx] = "";
		}
	}
	
	static public void SetLogHeader(params object[] ss) {
		MakeUtilsGameObject();
		SetLogHeader( 0, ss );
		//LOG_HEADER = ArrayToTabbedString(ss);
	}
	static public void SetLogHeader(int ndx, params object[] ss) {
		MakeUtilsGameObject();
		while (ndx >= LOG_HEADERS.Count) {
			LOG_HEADERS.Add("");
		}
		LOG_HEADERS[ndx] = ArrayToTabbedString(ss);
	}
	
	static public string LOG_HEADER {
		get {
			return(_LOG_HEADER);
		}
		set {
			if (value != _LOG_HEADER) {
				_LOG_HEADER = value;
			}
		}
	}
	
	/*
	static public void Log(string s) {
		MakeUtilsGameObject();
		
		Log(new string[] {s});
	}
	static public void Log(params object[] ss) {
		MakeUtilsGameObject();
		
		string str = ArrayToTabbedString(ss);
		str += "\r";
		LOG += str;
		if (TRACE_LOG) Debug.Log(str);
	}
	
	static public void PrintLog() {
		MakeUtilsGameObject();
		string str = "=====LOG=====\tFrame\ttime\tfixedTime\r";
		str += ArrayToTabbedString("", Time.frameCount, Time.time, Time.fixedTime)+"\r\r";
		if (LOG_HEADER.Length>0) str += LOG_HEADER+"\r";
		Debug.Log(str+LOG);
		LOG += "\r\r\r\r\r";
		if (CLEAR_LOG_ON_PRINT) {
			LOG = "";
			LOG_HEADER = "";
		}
	}
	
	static public void SetLogHeader(params object[] ss) {
		LOG_HEADER = ArrayToTabbedString(ss);
	}
	
	static public string LOG_HEADER {
		get {
			return(_LOG_HEADER);
		}
		set {
			if (value != _LOG_HEADER) {
				_LOG_HEADER = value;
			}
		}
	}
	*/
	
	
	// These identical functions bypass the log entirely but still take params as input and output to Debug.Log
	static public void Print(params object[] ss) {
		MakeUtilsGameObject();
		
		Debug.Log(ArrayToTabbedString(ss)+"\r");
	}
	static public void Tr(params object[] ss) {
		MakeUtilsGameObject();
		
		Debug.Log(ArrayToTabbedString(ss)+"\r");
	}
	
	
	static public string AddCommasToNumber(float n) {
// TODO: Actually add the decimals to these numbers
		return( AddCommasToNumber( Mathf.RoundToInt(n) ) );
	}
	static public string AddCommasToNumber(int n) {
		int rem;
		int div;
		string res = "";
		string rems;
		while (n>0) {
			rem = n % 1000;
			div = n / 1000;
			rems = rem.ToString();
			
			while (div>0 && rems.Length<3) {
				rems = "0"+rems;
			}
// TODO: I think there must be a faster way to concatenate strings. Maybe I could do this with an array or something
			if (res == "") {
				res = rems;
			} else {
				res = rems + "," + res.ToString();
			}
			n = div;
		}
		if (res == "") res = "0";
		return( res );
	}
	
	/* Old Versions
	static public void Log(string s) {
		Log(new string[] {s});
	}
	static public void Log(params string[] ss) {
		string str = ss[0];
		for (int i=1; i<ss.Length; i++) {
			str += "\t"+ss[i];
		}
		str += "\r";
		LOG += str;
		if (TRACE_LOG) print(str);
	}
	
	static public void PrintLog() {
		print(LOG);
		LOG += "\r\r\r\r";
		if (CLEAR_LOG_ON_PRINT) LOG = "";
	}
	*/
	
	
	
	
	
	
	static public float[] ParseStringListToFloatArray( string eAtt ) {
		string[] sArr = eAtt.Split(',');
		float[] fArr = new float[sArr.Length];
		for (int i=0; i<sArr.Length; i++) {
			fArr[i] = float.Parse( sArr[i] );
		}
		return( fArr );
	}
	
	
	static public int[] ParseStringListToIntArray( string eAtt ) {
		string[] sArr = eAtt.Split(',');
		int[] iArr = new int[sArr.Length];
		for (int i=0; i<sArr.Length; i++) {
			iArr[i] = int.Parse( sArr[i] );
		}
		return( iArr );
	}
	
// ====================== Mathematical Functions ======================
	static public bool IsEven(int i) {
		return( i%2 == 0 );
	}
	static public bool IsOdd(int i) {
		return( !IsEven(i) );
	}
	
	static public float FloatListMean( List<float> l ) {
		if (l.Count == 0) return(0);
		float tot = 0;
		int count = 0;
		foreach (float f in l) {
			tot += f;
			count++;
		}
		tot /= count;
		return( tot );
	}
	
	
	static public Vector3 Vector3ListMean( params Vector3[] vv ) {
		return( Vector3ListMean( new List<Vector3>(vv) ));
	}
	static public Vector3 Vector3ListMean( List<Vector3> l ) {
		if (l.Count == 0) return(Vector3.zero);
		Vector3 tot = Vector3.zero;
		int count = 0;
		foreach (Vector3 v3 in l) {
			tot += v3;
			count++;
		}
		tot /= count;
		return( tot );
	}
	
	
	static public string ToRoman(int number) {
		if ((number < 0) || (number > 3999)) {
			Debug.LogError("Utils.ToRoman: input of out range [1..3999]\t"+number.ToString());
			return("");
		}
        if (number < 1) return("");
        if (number >= 1000)	return("M" + ToRoman(number - 1000));
        if (number >= 900)	return("CM" + ToRoman(number - 900));
        if (number >= 500)	return("D" + ToRoman(number - 500));
        if (number >= 400)	return("CD" + ToRoman(number - 400));
        if (number >= 100)	return("C" + ToRoman(number - 100));           
        if (number >= 90)	return("XC" + ToRoman(number - 90));
        if (number >= 50)	return("L" + ToRoman(number - 50));
        if (number >= 40)	return("XL" + ToRoman(number - 40));
        if (number >= 10)	return("X" + ToRoman(number - 10));
        if (number >= 9)	return("IX" + ToRoman(number - 9));
        if (number >= 5)	return("V" + ToRoman(number - 5));
        if (number >= 4)	return("IV" + ToRoman(number - 4));
        if (number >= 1)	return("I" + ToRoman(number - 1));
		
		return("");
    }
	
	
	static public string PadLeadingZeroes(int n, int toPlaces) {
		string s = n.ToString();
		while (s.Length < toPlaces) {
			s = "0"+s;
		}
		return( s );
	}
	
	
	static public Vector2 Vector3to2( Vector3 v3, bool useXZ = false ) {
		if (!useXZ) {
			return( new Vector2( v3.x, v3.y ) );
		} else {
			return( new Vector2( v3.x, v3.z ) );
		}
	}
	
	
	
// ====================== Rotation Functions ======================
	
	static public float LimitRotation(float r) {
		while (r < -180) {
			r += 360;
		}
		while (r > 180) {
			r -= 360;
		}
		return(r);
	}
	
	static public float LimitRotation(float r, float r0) {
		while (r-r0 < -180) {
			r += 360;
		}
		while (r-r0 > 180) {
			r -= 360;
		}
		return(r);
	}
	
	static public float RotDiff(float r0, float r1) {
		r1 = LimitRotation( r1, r0 );
		float r = r1-r0;
		return(r);
	}
	
	
	
// ====================== Fuzzy Equality Functions ======================
	
	static public bool Eq( Vector3 v0, Vector3 v1, float toWithin=0.1f, bool checkDimensionsSeparately=false ) {
		Vector3 v01 = v1-v0; //Utils.Abs( v1-v0 );
		if ( !checkDimensionsSeparately ) {
			return ( v01.magnitude <= toWithin );
		} else {
			if (v01.x > -toWithin && v01.x < toWithin) {
				if (v01.y > -toWithin && v01.y < toWithin) {
					if (v01.z > -toWithin && v01.z < toWithin) {
						return(true);
					}
				}
			}
		}
		return(false);
	}
	
	static public bool EqV2( Vector2 v0, Vector2 v1, float toWithin=0.1f, bool checkDimensionsSeparately=false ) {
		Vector2 v01 = v1-v0;
		if ( !checkDimensionsSeparately ) {
			return ( v01.magnitude <= toWithin );
		} else {
			if (v01.x > -toWithin && v01.x < toWithin) {
				if (v01.y > -toWithin && v01.y < toWithin) {
					return(true);
				}
			}
		}
		return(false);
	}
	
	
// ====================== Absolute Value Functions ======================
	
	static public float Abs(float f) {
		return( Mathf.Abs(f) );
	}
	static public Vector2 Abs( Vector2 v ) {
		v.x = Mathf.Abs(v.x);
		v.y = Mathf.Abs(v.y);
		return( v );
	}
	static public Vector3 Abs( Vector3 v ) {
		v.x = Mathf.Abs(v.x);
		v.y = Mathf.Abs(v.y);
		v.z = Mathf.Abs(v.z);
		return( v );
	}
	
	
// ====================== Mesh Functions ======================
	public static void AddBackfacesToMesh( Mesh m ) {
		int len = m.triangles.Length;
		int[] triangles = new int[len*2];
		for (int i=0; i<m.triangles.Length; i += 3) {
			triangles[i]   = m.triangles[i];
			triangles[i+1] = m.triangles[i+1];
			triangles[i+2] = m.triangles[i+2];
			
			triangles[len+i]   = m.triangles[i];
			triangles[len+i+1] = m.triangles[i+2];
			triangles[len+i+2] = m.triangles[i+1];
		}
		m.triangles = triangles;
	}
	
	public static void MeshRemoveDuplicateVertices( Mesh m, bool testUV=false, bool testNormal=false) {
		//Mesh m2 = new Mesh();
		// Find and remove identical Vertices
		Vector3 v, n;
		Vector2 uv;
		XnUtils.SPLIT_VECTOR_COMPONENTS_ON_LOG = false;
		//Utils.Print(m.vertices);
		XnUtils.SPLIT_VECTOR_COMPONENTS_ON_LOG = true;
		// PMC working to fix null reference crash
		if (m == null || m.triangles == null)
		{
			return;	
		}
		// end PMC
		List<int> triangles = new List<int>(m.triangles);
		List<int> identicalVerts = new List<int>();
		List<int> vertsToRemove = new List<int>();
		List<Vector3> verts = new List<Vector3>(m.vertices);
		List<Vector2> uvs = new List<Vector2>(m.uv);
		List<Vector3> normals = new List<Vector3>(m.normals);
		// Go through all of the vertices
		for (int i=0; i<m.vertexCount; i++) {
			if (vertsToRemove.IndexOf(i) != -1) continue; // Don't check if we're already removing this vert
			v = m.vertices[i];
			uv = m.uv[i];
			n = m.normals[i];
			identicalVerts.Clear();
			for (int j=i+1; j<m.vertexCount; j++) {
				// If another vertex is identical, then add it to the list to replace
				if (!Eq( m.vertices[j], v, 0.1f)) continue;
				if (testUV && !Eq(m.uv[j], uv, 0.1f)) continue;
				if (testNormal && !Eq(m.normals[j], n, 0.1f)) continue;
				/*
				if (m.vertices[j] != v) continue;
				if (testUV && m.uv[j] != uv) continue;
				if (testNormal && m.normals[j] != n) continue;
				*/
				identicalVerts.Add(j);
				vertsToRemove.Add(j);
			}
			if (identicalVerts.Count > 0) {
				//Debug.Log("break");
			}
			for (int k=0; k<triangles.Count; k++) {
				// If a triangle used one of the identicalVerts, replace it with the base vert
				if (identicalVerts.IndexOf(triangles[k]) > -1) {
					triangles[k] = i;
				}
			}
			/*
			for (int k=0; k<m.triangles.Length; k++) {
				// If a triangle used one of the identicalVerts, replace it with the base vert
				if (identicalVerts.IndexOf(m.triangles[k]) > -1) m.triangles[k] = i;
			}
			*/
		}
		// Ripple-delete the verts (which is going to take time!)
		vertsToRemove.Sort();
		int ndx;
		for (int i=vertsToRemove.Count-1; i>=0; i--) {
			ndx = vertsToRemove[i];
			verts.RemoveAt(ndx);
			uvs.RemoveAt(ndx);
			normals.RemoveAt(ndx);
		}
		// Now we have culled verts, uvs, and normals
		// Rearrange the triangles to point at the right verts
		int gt;
		for (int i=0; i<triangles.Count; i++) {
			// find out how many vertsToRemove this reference is larger than
			gt=0;
			ndx = triangles[i];
			for (int j=0; j<vertsToRemove.Count; j++) {
				if (vertsToRemove[j] < ndx)
					gt++;
				else
					break;
			}
			triangles[i] = ndx-gt;
		}
			
		
		/*
		// Now we have culled verts, uvs, and normals
		// Rearrange the triangles to point at the right verts
		for (int i=0; i<m.triangles.Length; i++) {
			// Find the m.vertex referred to in m.triangles[i]
			v = m.vertices[ m.triangles[i] ];
			for (int j=0; j<verts.Count; j++) {
				// Search through verts to find an identical Vector3
				if (v == verts[j]) {
					// Set the triangle to be the index of that Vector3
					m.triangles[i] = j;
					break;
				}
			}
		}
		*/
		m.triangles = triangles.ToArray();
		m.vertices = verts.ToArray();
		m.uv = uvs.ToArray();
		m.normals = normals.ToArray();
		
		MeshRemoveDuplicateTriangles(m);
	}
	
	public struct TriInt3 {
		public int x, y, z;
		
		public TriInt3 ( int eX, int eY, int eZ ) {
			x = eX;
			y = eY;
			z = eZ;
		}
		
		public static bool operator == (TriInt3 e1, TriInt3 e2) {
			// NOTE: This assumes that x, y, & z are different!!!
			// If each of the three verts in e1 match one of the verts in e2, they are equal
			// NOTE: This ignores vert ordering for backface culling and such
			if (e1.x==e2.x || e1.x==e2.y || e1.x==e2.z) {
				if (e1.y==e2.x || e1.y==e2.y || e1.y==e2.z) {
					if (e1.z==e2.x || e1.z==e2.y || e1.z==e2.z) {
						return( true );
					}
				}
			}
			return( false );
		}
		
		public static bool operator != (TriInt3 e1, TriInt3 e2) {
			// NOTE: This assumes that x, y, & z are different!!!
			// If each of the three verts in e1 match one of the verts in e2, they are equal
			// NOTE: This ignores vert ordering for backface culling and such
			if (e1.x==e2.x || e1.x==e2.y || e1.x==e2.z) {
				if (e1.y==e2.x || e1.y==e2.y || e1.y==e2.z) {
					if (e1.z==e2.x || e1.z==e2.y || e1.z==e2.z) {
						return( false );
					}
				}
			}
			return( true );
		}
	}
	
	
	public static void MeshRemoveDuplicateTriangles( Mesh m ) {
		List<TriInt3> triInts = new List<TriInt3>();
		// Create a grouping of the triangles
		for (int i=0; i<m.triangles.Length; i+=3) {
			triInts.Add( new TriInt3( m.triangles[i], m.triangles[i+1], m.triangles[i+2] ) );
		}
		// Search backwards through the triangles to find duplicates
		TriInt3 ti;
		for (int i=triInts.Count-1; i>=0; i--) {
			ti = triInts[i];
			for (int j=i-1; j>=0; j--) {
				if (triInts[j] == ti) {
					// If an earlier TriInt3 == this one, remove this one
					triInts.RemoveAt(i);
					break;
				}
			}
		}
		// Spit this information back out to m.triangles
		List<int> triangles = new List<int>();
		foreach (TriInt3 ti3 in triInts) {
			triangles.Add(ti3.x);
			triangles.Add(ti3.y);
			triangles.Add(ti3.z);
		}
		m.triangles = triangles.ToArray();
	}
	
	/* This is supposed to be covered by Instantiate(Mesh)
	public static Mesh CloneMesh(Mesh m) {
		Mesh c = new Mesh();
		c.vertices = m.vertices.Clone();
		c.normals = m.normals.Clone();
		c.
	}
	*/
	
	
// ====================== Transform Functions ======================
	
	// This finds a much better version of lossyScale than Unity provides!
	public static Vector3 LossyScale(Transform t) {
		if (t.parent == null) return(Vector3.one);
		Vector3 v = LossyScale(t.parent);
		v.x *= t.localScale.x;
		v.y *= t.localScale.y;
		v.z *= t.localScale.z;
		return(v);
	}
	
	public static Vector3 ScaleVectorByVector(Vector3 v, Vector3 scale) {
		v.x *= scale.x;
		v.y *= scale.y;
		v.z *= scale.z;
		return(v);
	}
	
	
// ====================== Xbox 360 Controller Functions ======================
/* The Xbox 360 controller has different button mappings for Mac and PC, which sucks.
 * This tries to fix that.
 * =========================================================================== */
	public static Dictionary<XnXboxControl,string>	XnXboxControlDict;
	public static KeyCode[]							XnJoystickButtons;
	public static string[]							XnXboxControlCodes;
	
	public static XnControlState XnGetXbox360Control( string con ) {
		// The XnXboxControlDict handles the platform specific setup
		if (XnXboxControlDict == null) XnSetUpXnXboxControlDict();
		
		int num = Array.IndexOf( XnXboxControlCodes, con);
		if (num == -1) {
			return( new XnControlState() );
		}
		XnXboxControl xxc = (XnXboxControl) num;
		return( XnGetXbox360Control( xxc ) );
	}
	
	public static XnControlState XnGetXbox360Control( XnXboxControl xcon ) {
		// The XnXboxControlDict handles the platform specific setup
		if (XnXboxControlDict == null) XnSetUpXnXboxControlDict();
		
		XnControlState state = new XnControlState();
		
		if (!XnXboxControlDict.ContainsKey(xcon)) {
			state.error = ArrayToTabbedString("ERROR","XnUtils","GetXbox360Control( "+xcon+" )","Unknown control spec.");
			Print(state.error);
			return( state );
		}
		
		string con2string = XnXboxControlDict[xcon];
		string[] con2 = con2string.Split('_');
		switch (con2[0]) {
		case "b":
			int con2i = int.Parse(con2[1]);
			KeyCode buttonCode = XnJoystickButtons[con2i];
			state.state = Input.GetKey(buttonCode);
			state.up = Input.GetKeyUp(buttonCode);
			state.down = Input.GetKeyDown(buttonCode);
			state.button = xcon;
			state.keyCode = buttonCode;
			return( state );
			
		case "a":
			
			
			break;
		}
		
		state.error = ArrayToTabbedString("ERROR","XnUtils","GetXbox360Control( "+xcon+" )","Not handled.");
		Print(state.error);
		return( state );
	}
	
	public static void XnSetUpXnXboxControlDict() {
		XnXboxControlDict = new Dictionary<XnXboxControl, string>();
		switch (Application.platform) {
		case RuntimePlatform.OSXPlayer:
		case RuntimePlatform.OSXEditor:
			XnXboxControlDict.Add(XnXboxControl.b_a,"b_16");
			XnXboxControlDict.Add(XnXboxControl.b_b,"b_17");
			XnXboxControlDict.Add(XnXboxControl.b_x,"b_18");
			XnXboxControlDict.Add(XnXboxControl.b_y,"b_19");
			XnXboxControlDict.Add(XnXboxControl.la_x,"a_x");
			XnXboxControlDict.Add(XnXboxControl.la_y,"a_y");
			XnXboxControlDict.Add(XnXboxControl.ra_x,"a_3");
			XnXboxControlDict.Add(XnXboxControl.ra_y,"a_4");
			XnXboxControlDict.Add(XnXboxControl.dp_u,"b_5");
			XnXboxControlDict.Add(XnXboxControl.dp_d,"b_6");
			XnXboxControlDict.Add(XnXboxControl.dp_l,"b_7");
			XnXboxControlDict.Add(XnXboxControl.dp_r,"b_8");
			XnXboxControlDict.Add(XnXboxControl.back,"b_10");
			XnXboxControlDict.Add(XnXboxControl.start,"b_9");
			XnXboxControlDict.Add(XnXboxControl.home,"b_15");
			XnXboxControlDict.Add(XnXboxControl.l_trig,"a_5");
			XnXboxControlDict.Add(XnXboxControl.r_trig,"a_6");
			XnXboxControlDict.Add(XnXboxControl.lb,"b_13");
			XnXboxControlDict.Add(XnXboxControl.rb,"b_14");
			XnXboxControlDict.Add(XnXboxControl.b_la,"b_11");
			XnXboxControlDict.Add(XnXboxControl.b_ra,"b_12");
			break;
			
		case RuntimePlatform.WindowsPlayer:
		case RuntimePlatform.WindowsEditor:
			XnXboxControlDict.Add(XnXboxControl.b_a,"b_0");
			XnXboxControlDict.Add(XnXboxControl.b_b,"b_1");
			XnXboxControlDict.Add(XnXboxControl.b_x,"b_2");
			XnXboxControlDict.Add(XnXboxControl.b_y,"b_3");
			XnXboxControlDict.Add(XnXboxControl.la_x,"a_x");
			XnXboxControlDict.Add(XnXboxControl.la_y,"a_y");
			XnXboxControlDict.Add(XnXboxControl.ra_x,"a_4");
			XnXboxControlDict.Add(XnXboxControl.ra_y,"a_5");
			XnXboxControlDict.Add(XnXboxControl.dp_u,"a_6");
			XnXboxControlDict.Add(XnXboxControl.dp_d,"a_6");
			XnXboxControlDict.Add(XnXboxControl.dp_l,"a_7");
			XnXboxControlDict.Add(XnXboxControl.dp_r,"a_7");
			XnXboxControlDict.Add(XnXboxControl.back,"b_6");
			XnXboxControlDict.Add(XnXboxControl.start,"b_7");
			XnXboxControlDict.Add(XnXboxControl.home,"");
			XnXboxControlDict.Add(XnXboxControl.l_trig,"a_9");
			XnXboxControlDict.Add(XnXboxControl.r_trig,"a_10");
			XnXboxControlDict.Add(XnXboxControl.lb,"b_4");
			XnXboxControlDict.Add(XnXboxControl.rb,"b_5");
			XnXboxControlDict.Add(XnXboxControl.b_la,"b_8");
			XnXboxControlDict.Add(XnXboxControl.b_ra,"b_9");
			break;
		}
		
/*
	public static void XnSetUpXnXboxControlDict() {
		XnXboxControlDict = new Dictionary<string, string>();
		switch (Application.platform) {
		case RuntimePlatform.OSXPlayer:
		case RuntimePlatform.OSXEditor:
			XnXboxControlDict.Add("b_a","b_16");
			XnXboxControlDict.Add("b_b","b_17");
			XnXboxControlDict.Add("b_x","b_18");
			XnXboxControlDict.Add("b_y","b_19");
			XnXboxControlDict.Add("la_x","a_x");
			XnXboxControlDict.Add("la_y","a_y");
			XnXboxControlDict.Add("ra_x","a_3");
			XnXboxControlDict.Add("ra_y","a_4");
			XnXboxControlDict.Add("dp_u","b_5");
			XnXboxControlDict.Add("dp_d","b_6");
			XnXboxControlDict.Add("dp_l","b_7");
			XnXboxControlDict.Add("dp_r","b_8");
			XnXboxControlDict.Add("back","b_10");
			XnXboxControlDict.Add("start","b_9");
			XnXboxControlDict.Add("home","b_15");
			XnXboxControlDict.Add("l_trig","a_5");
			XnXboxControlDict.Add("r_trig","a_6");
			XnXboxControlDict.Add("lb","b_13");
			XnXboxControlDict.Add("rb","b_14");
			XnXboxControlDict.Add("b_la","b_11");
			XnXboxControlDict.Add("b_ra","b_12");
			break;
			
		case RuntimePlatform.WindowsPlayer:
		case RuntimePlatform.WindowsEditor:
			XnXboxControlDict.Add("b_a","b_0");
			XnXboxControlDict.Add("b_b","b_1");
			XnXboxControlDict.Add("b_x","b_2");
			XnXboxControlDict.Add("b_y","b_3");
			XnXboxControlDict.Add("la_x","a_x");
			XnXboxControlDict.Add("la_y","a_y");
			XnXboxControlDict.Add("ra_x","a_4");
			XnXboxControlDict.Add("ra_y","a_5");
			XnXboxControlDict.Add("dp_u","a_6");
			XnXboxControlDict.Add("dp_d","a_6");
			XnXboxControlDict.Add("dp_l","a_7");
			XnXboxControlDict.Add("dp_r","a_7");
			XnXboxControlDict.Add("back","b_6");
			XnXboxControlDict.Add("start","b_7");
			XnXboxControlDict.Add("home","");
			XnXboxControlDict.Add("l_trig","a_9");
			XnXboxControlDict.Add("r_trig","a_10");
			XnXboxControlDict.Add("lb","b_4");
			XnXboxControlDict.Add("rb","b_5");
			XnXboxControlDict.Add("b_la","b_8");
			XnXboxControlDict.Add("b_ra","b_9");
			break;
		}
*/		
		
		
		XnJoystickButtons = new KeyCode[] {
			KeyCode.JoystickButton0,
			KeyCode.JoystickButton1,
			KeyCode.JoystickButton2,
			KeyCode.JoystickButton3,
			KeyCode.JoystickButton4,
			KeyCode.JoystickButton5,
			KeyCode.JoystickButton6,
			KeyCode.JoystickButton7,
			KeyCode.JoystickButton8,
			KeyCode.JoystickButton9,
			KeyCode.JoystickButton10,
			KeyCode.JoystickButton11,
			KeyCode.JoystickButton12,
			KeyCode.JoystickButton13,
			KeyCode.JoystickButton14,
			KeyCode.JoystickButton15,
			KeyCode.JoystickButton16,
			KeyCode.JoystickButton17,
			KeyCode.JoystickButton18,
			KeyCode.JoystickButton19 };
		
		// This variable allows conversion from string back to enum XnXboxControl
		XnXboxControlCodes = new string[] {
				"b_a",
				"b_b",
				"b_x",
				"b_y",
				"la_x",
				"la_y",
				"ra_x",
				"ra_y",
				"dp_u",
				"dp_d",
				"dp_l",
				"dp_r",
				"back",
				"start",
				"home",
				"l_trig",
				"r_trig",
				"lb",
				"rb",
				"b_la",
				"b_ra"	};
	}
	
}

public class XnControlState {
	public XnXboxControl	button;
	public bool				state = false;
	public bool				up = false;
	public bool				down = false;
	public float			val = 0f;
	public string			error = "";
	public KeyCode			keyCode;
}

public enum XnXboxControl {
	b_a,
	b_b,
	b_x,
	b_y,
	la_x,
	la_y,
	ra_x,
	ra_y,
	dp_u,
	dp_d,
	dp_l,
	dp_r,
	back,
	start,
	home,
	l_trig,
	r_trig,
	lb,
	rb,
	b_la,
	b_ra
}