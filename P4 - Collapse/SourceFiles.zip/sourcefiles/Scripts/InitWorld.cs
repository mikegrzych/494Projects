﻿using UnityEngine;
using System.Collections;

public class InitWorld : MonoBehaviour {

	public GameObject GolemPrefab;
	public GameObject CyborgPrefab;

	public Vector3 spawn_loc;
	public Quaternion spawn_direction;

	private GlobalPlayer _me;

	// Use this for initialization
	void Start () {
//		Vector3 spawn_loc;
		GameObject go = GameObject.Find("Me");
		// Hack to debug combat
		if (go == null) {
			go = Instantiate(Resources.Load("Me")) as GameObject;
			go.name = "Me";
		}
		GlobalPlayer cs = go.GetComponent<GlobalPlayer>();
		if (cs.Team == TeamId.RED) {
			spawn_loc = (GameObject.Find("Team0Base")).GetComponent<Transform>().position;
			spawn_direction = Quaternion.Euler(0,90,0);
		} else {
			spawn_loc = (GameObject.Find("Team1Base")).GetComponent<Transform>().position;
			spawn_direction = Quaternion.Euler(0,90,0);
		}

		//Determine what character to play as
		GameObject player;
		print ("Character selected: " + cs.Character.ToString());
		if (cs.Character == CharacterId.CYBORG) {
			player = (GameObject) Network.Instantiate(CyborgPrefab, spawn_loc, spawn_direction, 0);
		}
		else {

			player = (GameObject) Network.Instantiate(GolemPrefab, spawn_loc, spawn_direction, 0);
		}

		SmartCameraFollow cam = (GameObject.Find("Main Camera")).GetComponent<SmartCameraFollow>();
//		player.name = "Player " + Network.player.ToString();
		player.GetComponent<CharacterStatus>().SetName(cs.Name); //= cs.Name;
//		player.GetComponent<CharacterStatus>().Name = cs.Name;
		player.GetComponent<CharacterStatus>().SetTeam(cs.Team);
		player.networkView.RPC("RPC_SetTeamNumber", RPCMode.Others, cs.TeamInt);
		player.GetComponent<CharacterStatus>().SetRespawnPoint(spawn_loc);

		cam.target = player.transform;
		Destroy(go);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
