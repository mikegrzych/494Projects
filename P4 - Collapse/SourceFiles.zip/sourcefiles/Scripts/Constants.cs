﻿using UnityEngine;
using System.Collections;

// I actually have reasons for these numbers
public enum TeamId { RED = 0, BLUE = 1, SPECTATOR = 8, NEUTRAL = -1 };
public enum CharacterId { ICE_GOLEM = 0, CYBORG };

public enum MenuState { MAIN, JOIN, HOST, LOBBY, TUTORIAL };

public class CharacterUtils {
	public static string[] CHARACTER_NAMES = { "Ice Golem", "Cyborg" };

	public static CharacterId GetCharacter(int index) {
		switch (index) {
		case 0:
			return CharacterId.ICE_GOLEM;
		case 1:
			return CharacterId.CYBORG;
		default:
			return CharacterId.ICE_GOLEM;
		}
	}

}


public class NetUtils {
	public const string NET_GAME_TYPE = "CollapseGame494";
	public const string OPEN_GAME = "open";
	public const string CLOSED_GAME = "closed";
}

public class TeamUtils {

	public static string[] TEAM_NAMES = { "RED", "BLUE" };

	public static TeamId GetTeam(int teamNumber) {
		switch (teamNumber) {
		case 0:
			return TeamId.RED;
		case 1:
			return TeamId.BLUE;
		case 8:
			return TeamId.SPECTATOR;
		default:
			return TeamId.NEUTRAL;
		}
	}

	public static string GetName(TeamId team) {
		switch (team) {
		case TeamId.RED:
			return "RED";
		case TeamId.BLUE:
			return "BLUE";
		case TeamId.SPECTATOR:
			return "SPECTATOR";
		default:
			return "";
		}
	}
}